import GroupComponent1 from "../components/GroupComponent1";
import Header from "../components/Header";
import Footer from "../components/Footer";
import styles from "./HomePage.module.css";

const HomePage = () => {
  return (
    <div className={styles.homePage}>
      <GroupComponent1 />
      <Header />
      <img className={styles.main1Icon} alt="" src="/main-1@2x.png" />
      <Footer rectangle146="/rectangle-146.svg" />
    </div>
  );
};

export default HomePage;
