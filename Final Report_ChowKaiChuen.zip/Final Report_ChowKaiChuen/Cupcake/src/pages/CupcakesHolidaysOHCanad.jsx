import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import GroupComponent from "../components/GroupComponent";
import Footer from "../components/Footer";
import styles from "./CupcakesHolidaysOHCanad.module.css";

const CupcakesHolidaysOHCanad = () => {
  const navigate = useNavigate();

  const onCUPCAKESTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available");
  }, [navigate]);

  const onHolidaysTextClick = useCallback(() => {
    navigate("/cupcakes-holidays-mother-day");
  }, [navigate]);

  const onEventTextClick = useCallback(() => {
    navigate("/cupcakes-event");
  }, [navigate]);

  const onOthersTextClick = useCallback(() => {
    navigate("/cupcakes-others");
  }, [navigate]);

  const onValentinesDayTextClick = useCallback(() => {
    navigate("/cupcakes-holidays-valentines-day");
  }, [navigate]);

  const onEASTERTextClick = useCallback(() => {
    navigate("/cupcakes-holidays-easter");
  }, [navigate]);

  const onStPattysDayClick = useCallback(() => {
    navigate("/cupcakes-holidays-st-patty");
  }, [navigate]);

  return (
    <div className={styles.cupcakesHolidaysOhCanad}>
      <GroupComponent onCUPCAKESTextClick={onCUPCAKESTextClick} />
      <section className={styles.cupcakesHolidaysOhCanadInner}>
        <div className={styles.frameParent}>
          <div className={styles.cupcakesAvailabilityParent}>
            <div className={styles.cupcakesAvailability}>
              <h1 className={styles.cupcakes}>CUPCAKES</h1>
            </div>
            <div className={styles.availabilityOptions}>
              <div className={styles.alwaysAvailableOptions}>
                <h1
                  className={styles.alwaysAvailable}
                  onClick={onCUPCAKESTextClick}
                >
                  always available
                </h1>
                <h1 className={styles.holidays} onClick={onHolidaysTextClick}>
                  holidays
                </h1>
              </div>
              <div className={styles.eventOption}>
                <h1 className={styles.event} onClick={onEventTextClick}>
                  event
                </h1>
              </div>
              <h1 className={styles.others} onClick={onOthersTextClick}>
                others
              </h1>
            </div>
          </div>
          <div className={styles.quantityOptions}>
            <h2 className={styles.each24}>
              $3.75 each | $24 half dozen | $48 dozen
            </h2>
          </div>
        </div>
      </section>
      <div className={styles.categoriesContentWrapper}>
        <div className={styles.categoriesContent}>
          <b className={styles.categories}>CATEGORIES</b>
          <div className={styles.categoriesOptions}>
            <div className={styles.categoriesList}>
              <div className={styles.mothersDay} onClick={onHolidaysTextClick}>
                mother’s day
              </div>
              <div className={styles.categoriesItems}>
                <div
                  className={styles.mothersDay}
                  onClick={onValentinesDayTextClick}
                >
                  Valentine's Day
                </div>
              </div>
              <div className={styles.categoriesItems}>
                <a className={styles.easter} onClick={onEASTERTextClick}>
                  EASTER
                </a>
              </div>
              <div className={styles.categoriesItems2}>
                <div className={styles.ohCanadaCanada}>
                  Oh Canada! Canada Day
                </div>
              </div>
              <div className={styles.mothersDay} onClick={onStPattysDayClick}>
                St Patty's Day cupcake
              </div>
            </div>
            <div className={styles.canadaDayCategory}>
              <div className={styles.canadaDayProduct}>
                <div className={styles.canadaday1Wrapper}>
                  <img
                    className={styles.canadaday1Icon}
                    loading="lazy"
                    alt=""
                    src="/canadaday-1@2x.png"
                  />
                </div>
                <div className={styles.ohCanadaCanada1}>
                  Oh Canada! Canada Day cupcake
                </div>
                <div className={styles.canadaDayAction}>
                  <div className={styles.frameGroup}>
                    <div className={styles.rectangleParent}>
                      <div className={styles.frameChild} />
                      <div className={styles.addToCartButtonComponents}>
                        <div
                          className={styles.addToCartButtonComponentsChild}
                        />
                        <div className={styles.separator}>-</div>
                      </div>
                      <div className={styles.addButtonLabelWrapper}>
                        <div className={styles.addButtonLabel}>1</div>
                      </div>
                      <div className={styles.addToCartButtonComponents1}>
                        <div
                          className={styles.addToCartButtonComponentsChild}
                        />
                        <div className={styles.div}>+</div>
                      </div>
                    </div>
                    <div className={styles.rectangleGroup}>
                      <div className={styles.frameItem} />
                      <div className={styles.addToCart}>add to cart</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer propMarginTop="unset" rectangle146="/rectangle-146.svg" />
    </div>
  );
};

export default CupcakesHolidaysOHCanad;
