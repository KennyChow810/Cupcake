import GroupComponent5 from "../components/GroupComponent5";
import FaqsContent from "../components/FaqsContent";
import Footer from "../components/Footer";
import styles from "./FAQs.module.css";

const FAQs = () => {
  return (
    <div className={styles.faqs}>
      <section className={styles.header}>
        <GroupComponent5 />
        <FaqsContent />
      </section>
      <Footer propMarginTop="unset" rectangle146="/rectangle-146.svg" />
    </div>
  );
};

export default FAQs;
