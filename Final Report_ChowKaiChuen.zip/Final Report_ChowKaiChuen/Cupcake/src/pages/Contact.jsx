import GroupComponent4 from "../components/GroupComponent4";
import Footer from "../components/Footer";
import styles from "./Contact.module.css";

const Contact = () => {
  return (
    <div className={styles.contact}>
      <GroupComponent4 />
      <section className={styles.infoDetailsWrapper}>
        <div className={styles.infoDetails}>
          <div className={styles.locationInfo}>
            <div className={styles.locationDetails}>
              <div className={styles.giveUsARingOrClickWrapper}>
                <h1 className={styles.giveUsA}>Give us a ring or click</h1>
              </div>
              <div className={styles.ourMainTorontoContainer}>
                <p className={styles.ourMainToronto}>
                  Our main Toronto location will be opening soon in the GTA! in
                  the meantime, please click to order for delivery
                </p>
              </div>
            </div>
          </div>
          <div className={styles.operationHours}>
            <div className={styles.operationTitle}>
              <div className={styles.hoursOfOperation}>Hours of operation</div>
            </div>
            <div className={styles.operationDays}>
              <div className={styles.daysDetails}>
                <div className={styles.daysList}>
                  <div className={styles.weAreOpenFromMondayToSunParent}>
                    <div className={styles.weAreOpen}>
                      We are open from monday to sunday
                    </div>
                    <div className={styles.scheduleDetails}>
                      <div className={styles.mondaySaturdayContainer}>
                        <p className={styles.ourMainToronto}>
                          <span>{`Monday - Saturday
`}</span>
                          <span className={styles.am10pm}>7am - 10pm</span>
                        </p>
                        <p className={styles.ourMainToronto}>Sunday</p>
                        <p className={styles.am10pm1}>
                          7am - 10pm (no pick ups, deliveries for 2doz or more)
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className={styles.contactInfo}>
                    <div className={styles.contactDetails}>
                      <div className={styles.contactUs}>Contact us</div>
                      <div className={styles.northAmerica18773349468Container}>
                        <p className={styles.ourMainToronto}>
                          North America: +1-877-334-9468
                        </p>
                        <p className={styles.ourMainToronto}>&nbsp;</p>
                        <p className={styles.ourMainToronto}>
                          Outside of North Am: +001-647-478-9464
                        </p>
                        <p className={styles.ourMainToronto}>&nbsp;</p>
                        <p className={styles.ourMainToronto}>
                          Local Toronto and GTA: 647-478-9464
                        </p>
                        <p className={styles.ourMainToronto}>&nbsp;</p>
                        <p className={styles.ourMainToronto}>
                          Email us at: inquiry@torontocupcake.com with any type
                          of question, concern or comment.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles.address}>
                <div className={styles.addressDetails}>
                  <div
                    className={styles.queenStE}
                  >{`Queen St E & Lee Ave Toronto,`}</div>
                </div>
                <img
                  className={styles.screenshot202111291832461}
                  alt=""
                  src="/screenshot-20211129-183246-1@2x.png"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
      <Footer propMarginTop="unset" rectangle146="/rectangle-146.svg" />
    </div>
  );
};

export default Contact;
