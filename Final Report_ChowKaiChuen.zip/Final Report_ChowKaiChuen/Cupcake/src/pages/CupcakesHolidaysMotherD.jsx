import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import GroupComponent from "../components/GroupComponent";
import ProductContainer from "../components/ProductContainer";
import Footer from "../components/Footer";
import styles from "./CupcakesHolidaysMotherD.module.css";

const CupcakesHolidaysMotherD = () => {
  const navigate = useNavigate();

  const onCUPCAKESTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available");
  }, [navigate]);

  return (
    <div className={styles.cupcakesHolidaysMotherD}>
      <GroupComponent onCUPCAKESTextClick={onCUPCAKESTextClick} />
      <section className={styles.productContainerWrapper}>
        <ProductContainer />
      </section>
      <Footer propMarginTop="unset" rectangle146="/rectangle-146.svg" />
    </div>
  );
};

export default CupcakesHolidaysMotherD;
