import Navbar from "../components/Navbar";
import FrameComponent3 from "../components/FrameComponent3";
import Footer from "../components/Footer";
import styles from "./AboutUs.module.css";

const AboutUs = () => {
  return (
    <div className={styles.aboutUs}>
      <Navbar />
      <FrameComponent3 />
      <section className={styles.founderContentParent}>
        <div className={styles.founderContent}>
          <div className={styles.founderInfo}>
            <div className={styles.aboutMichelleParent}>
              <h1 className={styles.aboutMichelle}>About Michelle</h1>
              <div className={styles.welcomeThankYou}>
                Toronto Cupcake was created by Michelle Harrison so she could
                pursue her love of baking. A lifelong baker, inspired by her
                mother, Michelle opened Toronto Cupcake in August 2010 as one of
                Canada's first gourmet cupcakeries.
              </div>
            </div>
            <img
              className={styles.aboutMainSm1Icon}
              loading="lazy"
              alt=""
              src="/about-main-sm-1@2x.png"
            />
          </div>
        </div>
        <Footer propMarginTop="unset" rectangle146="/rectangle-146.svg" />
      </section>
    </div>
  );
};

export default AboutUs;
