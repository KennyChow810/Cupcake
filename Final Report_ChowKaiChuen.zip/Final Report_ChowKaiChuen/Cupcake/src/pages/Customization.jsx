import GroupComponent3 from "../components/GroupComponent3";
import CelebrationContent from "../components/CelebrationContent";
import FrameComponent5 from "../components/FrameComponent5";
import styles from "./Customization.module.css";

const Customization = () => {
  return (
    <div className={styles.customization}>
      <GroupComponent3 />
      <section className={styles.customizationHeader}>
        <h1 className={styles.customization1}>CUSTOMIZATION</h1>
      </section>
      <section className={styles.celebrationContentWrapper}>
        <CelebrationContent />
      </section>
      <FrameComponent5 />
    </div>
  );
};

export default Customization;
