import { useCallback } from "react";
import GroupComponent from "../components/GroupComponent";
import { useNavigate } from "react-router-dom";
import CategoryItems from "../components/CategoryItems";
import Footer from "../components/Footer";
import styles from "./CupcakesAlwaysAvailable.module.css";

const CupcakesAlwaysAvailable = () => {
  const navigate = useNavigate();

  const onHolidaysTextClick = useCallback(() => {
    navigate("/cupcakes-holidays-mother-day");
  }, [navigate]);

  const onEventTextClick = useCallback(() => {
    navigate("/cupcakes-event");
  }, [navigate]);

  const onOthersTextClick = useCallback(() => {
    navigate("/cupcakes-others");
  }, [navigate]);

  return (
    <div className={styles.cupcakesAlwaysAvailable}>
      <GroupComponent />
      <div className={styles.cupcakesCategories}>
        <div className={styles.categoriesContainer}>
          <div className={styles.cupcakesAvailableParent}>
            <div className={styles.cupcakesAvailable}>
              <h1 className={styles.cupcakes}>CUPCAKES</h1>
            </div>
            <div className={styles.availabilityOptions}>
              <div className={styles.alwaysAvailableHolidays}>
                <h1 className={styles.alwaysAvailable}>always available</h1>
                <h1 className={styles.holidays} onClick={onHolidaysTextClick}>
                  holidays
                </h1>
              </div>
              <div className={styles.eventOption}>
                <h1 className={styles.event} onClick={onEventTextClick}>
                  event
                </h1>
              </div>
              <h1 className={styles.others} onClick={onOthersTextClick}>
                others
              </h1>
            </div>
          </div>
          <div className={styles.quantity}>
            <div className={styles.each2150}>
              $3.75 each | $21.50 half dozen | $41.5 dozen
            </div>
          </div>
        </div>
      </div>
      <main className={styles.categoriesList}>
        <section className={styles.categoriesScroll}>
          <CategoryItems />
          <div className={styles.assortedBoxContainer}>
            <div className={styles.assortedBoxDetails}>
              <div className={styles.oneDozenAssorted}>
                one dozen assorted box
              </div>
              <div className={styles.assortedBoxActions}>
                <div className={styles.rectangleParent}>
                  <div className={styles.frameChild} />
                  <div className={styles.assortedBoxElements}>
                    <div className={styles.assortedBoxElementsChild} />
                    <div className={styles.assortedBoxDelimiter}>-</div>
                  </div>
                  <div className={styles.assortedBoxPrice}>
                    <div className={styles.div}>1</div>
                  </div>
                  <div className={styles.assortedBoxElements1}>
                    <div className={styles.assortedBoxElementsChild} />
                    <div className={styles.div1}>+</div>
                  </div>
                </div>
                <div className={styles.rectangleGroup}>
                  <div className={styles.frameItem} />
                  <div className={styles.addToCart}>add to cart</div>
                </div>
              </div>
            </div>
          </div>
          <Footer propMarginTop="unset" rectangle146="/rectangle-146.svg" />
        </section>
        <div className={styles.assortedImage}>
          <img
            className={styles.assorteddozen1Icon}
            loading="lazy"
            alt=""
            src="/assorteddozen-1@2x.png"
          />
        </div>
      </main>
    </div>
  );
};

export default CupcakesAlwaysAvailable;
