import Main from "../components/Main";
import Footer from "../components/Footer";
import styles from "./CupcakesEvent.module.css";

const CupcakesEvent = () => {
  return (
    <div className={styles.cupcakesEvent}>
      <Main />
      <Footer propMarginTop="unset" rectangle146="/rectangle-146.svg" />
    </div>
  );
};

export default CupcakesEvent;
