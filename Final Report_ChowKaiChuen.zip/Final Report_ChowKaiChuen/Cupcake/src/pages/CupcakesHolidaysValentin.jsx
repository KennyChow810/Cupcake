import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import GroupComponent from "../components/GroupComponent";
import HalfDozenProduct from "../components/HalfDozenProduct";
import Footer from "../components/Footer";
import styles from "./CupcakesHolidaysValentin.module.css";

const CupcakesHolidaysValentin = () => {
  const navigate = useNavigate();

  const onCUPCAKESTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available");
  }, [navigate]);

  const onHolidaysTextClick = useCallback(() => {
    navigate("/cupcakes-holidays-mother-day");
  }, [navigate]);

  const onEventTextClick = useCallback(() => {
    navigate("/cupcakes-event");
  }, [navigate]);

  const onOthersTextClick = useCallback(() => {
    navigate("/cupcakes-others");
  }, [navigate]);

  const onEASTERTextClick = useCallback(() => {
    navigate("/cupcakes-holidays-easter");
  }, [navigate]);

  const onOhCanadaCanadaClick = useCallback(() => {
    navigate("/cupcakes-holidays-oh-canada");
  }, [navigate]);

  const onStPattysDayClick = useCallback(() => {
    navigate("/cupcakes-holidays-st-patty");
  }, [navigate]);

  return (
    <div className={styles.cupcakesHolidaysValentin}>
      <GroupComponent onCUPCAKESTextClick={onCUPCAKESTextClick} />
      <section className={styles.cupcakesContentWrapper}>
        <div className={styles.cupcakesContent}>
          <div className={styles.cupcakesOptions}>
            <div className={styles.optionsDetail}>
              <div className={styles.optionTypes}>
                <div className={styles.cupcakesHeading}>
                  <h1 className={styles.cupcakes}>CUPCAKES</h1>
                </div>
                <div className={styles.availabilityTypes}>
                  <div className={styles.availabilityOptions}>
                    <h1
                      className={styles.alwaysAvailable}
                      onClick={onCUPCAKESTextClick}
                    >
                      always available
                    </h1>
                    <h1
                      className={styles.holidays}
                      onClick={onHolidaysTextClick}
                    >
                      holidays
                    </h1>
                  </div>
                  <div className={styles.eventsAvailable}>
                    <h1 className={styles.event} onClick={onEventTextClick}>
                      event
                    </h1>
                  </div>
                  <h1 className={styles.others} onClick={onOthersTextClick}>
                    others
                  </h1>
                </div>
              </div>
              <div className={styles.quantityOptions}>
                <h2 className={styles.each24}>
                  $3.75 each | $24 half dozen | $48 dozen
                </h2>
              </div>
            </div>
          </div>
          <div className={styles.categoriesContentParent}>
            <div className={styles.categoriesContent}>
              <div className={styles.categoriesDetail}>
                <b className={styles.categories}>CATEGORIES</b>
                <div className={styles.categoriesList}>
                  <div
                    className={styles.mothersDay}
                    onClick={onHolidaysTextClick}
                  >
                    mother’s day
                  </div>
                  <div className={styles.valentinesCategory}>
                    <div className={styles.valentinesDay}>Valentine's Day</div>
                  </div>
                  <div className={styles.valentinesCategory}>
                    <div className={styles.easter} onClick={onEASTERTextClick}>
                      EASTER
                    </div>
                  </div>
                  <div className={styles.categoryItems1}>
                    <div
                      className={styles.mothersDay}
                      onClick={onOhCanadaCanadaClick}
                    >
                      Oh Canada! Canada Day
                    </div>
                  </div>
                  <div
                    className={styles.mothersDay}
                    onClick={onStPattysDayClick}
                  >
                    St Patty's Day cupcake
                  </div>
                </div>
              </div>
            </div>
            <HalfDozenProduct
              propGap="0.5px"
              propMinWidth="350px"
              torontoMothersDayHalfDozen="/toronto-12-valentines-1@2x.png"
              propGap1="10px"
              mothersDayHalfDozen="Valentine's Day"
              propHeight="unset"
            />
          </div>
        </div>
      </section>
      <Footer propMarginTop="unset" rectangle146="/rectangle-146.svg" />
    </div>
  );
};

export default CupcakesHolidaysValentin;
