import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import GroupComponent from "../components/GroupComponent";
import FrameComponent1 from "../components/FrameComponent1";
import Footer from "../components/Footer";
import styles from "./CupcakesHolidaysSTPatty.module.css";

const CupcakesHolidaysSTPatty = () => {
  const navigate = useNavigate();

  const onCUPCAKESTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available");
  }, [navigate]);

  const onHolidaysTextClick = useCallback(() => {
    navigate("/cupcakes-holidays-mother-day");
  }, [navigate]);

  const onEventTextClick = useCallback(() => {
    navigate("/cupcakes-event");
  }, [navigate]);

  const onOthersTextClick = useCallback(() => {
    navigate("/cupcakes-others");
  }, [navigate]);

  const onValentinesDayTextClick = useCallback(() => {
    navigate("/cupcakes-holidays-valentines-day");
  }, [navigate]);

  const onEASTERTextClick = useCallback(() => {
    navigate("/cupcakes-holidays-easter");
  }, [navigate]);

  const onOhCanadaCanadaClick = useCallback(() => {
    navigate("/cupcakes-holidays-oh-canada");
  }, [navigate]);

  return (
    <div className={styles.cupcakesHolidaysStPatty}>
      <GroupComponent onCUPCAKESTextClick={onCUPCAKESTextClick} />
      <section className={styles.cupcakesHolidaysStPattyInner}>
        <div className={styles.frameParent}>
          <div className={styles.frameGroup}>
            <div className={styles.cupcakesWrapper}>
              <h1 className={styles.cupcakes}>CUPCAKES</h1>
            </div>
            <div className={styles.frameContainer}>
              <div className={styles.alwaysAvailableParent}>
                <h1
                  className={styles.alwaysAvailable}
                  onClick={onCUPCAKESTextClick}
                >
                  always available
                </h1>
                <h1 className={styles.holidays} onClick={onHolidaysTextClick}>
                  holidays
                </h1>
              </div>
              <div className={styles.eventWrapper}>
                <h1 className={styles.event} onClick={onEventTextClick}>
                  event
                </h1>
              </div>
              <h1 className={styles.others} onClick={onOthersTextClick}>
                others
              </h1>
            </div>
          </div>
          <div className={styles.each24HalfDozen48DoWrapper}>
            <h2 className={styles.each24}>
              $3.75 each | $24 half dozen | $48 dozen
            </h2>
          </div>
        </div>
      </section>
      <div className={styles.cupcakesHolidaysStPattyChild}>
        <div className={styles.categoriesParent}>
          <b className={styles.categories}>CATEGORIES</b>
          <div className={styles.frameDiv}>
            <div className={styles.mothersDayParent}>
              <div className={styles.mothersDay} onClick={onHolidaysTextClick}>
                mother’s day
              </div>
              <div className={styles.valentinesDayWrapper}>
                <div
                  className={styles.mothersDay}
                  onClick={onValentinesDayTextClick}
                >
                  Valentine's Day
                </div>
              </div>
              <div className={styles.valentinesDayWrapper}>
                <div className={styles.easter} onClick={onEASTERTextClick}>
                  EASTER
                </div>
              </div>
              <div className={styles.ohCanadaCanadaDayWrapper}>
                <div
                  className={styles.mothersDay}
                  onClick={onOhCanadaCanadaClick}
                >
                  Oh Canada! Canada Day
                </div>
              </div>
              <div className={styles.stPattysDay}>St Patty's Day cupcake</div>
            </div>
            <FrameComponent1
              stpattysday1="/stpattysday-1@2x.png"
              stPattysDayCupcake="St Patty's Day cupcake"
            />
          </div>
        </div>
      </div>
      <Footer propMarginTop="unset" rectangle146="/rectangle-146.svg" />
    </div>
  );
};

export default CupcakesHolidaysSTPatty;
