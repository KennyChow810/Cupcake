import GroupComponent2 from "../components/GroupComponent2";
import CorporateEventHero from "../components/CorporateEventHero";
import FrameComponent4 from "../components/FrameComponent4";
import styles from "./CorporateEvent.module.css";

const CorporateEvent = () => {
  return (
    <div className={styles.corporateEvent}>
      <GroupComponent2 />
      <CorporateEventHero />
      <FrameComponent4 />
    </div>
  );
};

export default CorporateEvent;
