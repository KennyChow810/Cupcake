import FrameComponent7 from "../components/FrameComponent7";
import Footer from "../components/Footer";
import styles from "./CupcakesAlwaysAvailable3.module.css";

const CupcakesAlwaysAvailable3 = () => {
  return (
    <div className={styles.cupcakesAlwaysAvailable}>
      <FrameComponent7 />
      <Footer rectangle146="/rectangle-146.svg" />
    </div>
  );
};

export default CupcakesAlwaysAvailable3;
