import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import GroupComponent from "../components/GroupComponent";
import FrameComponent6 from "../components/FrameComponent6";
import Footer from "../components/Footer";
import styles from "./CupcakesHolidaysEaster.module.css";

const CupcakesHolidaysEaster = () => {
  const navigate = useNavigate();

  const onCUPCAKESTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available");
  }, [navigate]);

  return (
    <div className={styles.cupcakesHolidaysEaster}>
      <GroupComponent onCUPCAKESTextClick={onCUPCAKESTextClick} />
      <section className={styles.cupcakesHolidaysEasterInner}>
        <FrameComponent6 />
      </section>
      <Footer propMarginTop="unset" rectangle146="/rectangle-146.svg" />
    </div>
  );
};

export default CupcakesHolidaysEaster;
