import Main1 from "../components/Main1";
import Footer from "../components/Footer";
import styles from "./CupcakesOthers.module.css";

const CupcakesOthers = () => {
  return (
    <div className={styles.cupcakesOthers}>
      <Main1 />
      <Footer propMarginTop="unset" rectangle146="/rectangle-146.svg" />
    </div>
  );
};

export default CupcakesOthers;
