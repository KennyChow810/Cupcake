import Page from "../components/Page";
import Footer from "../components/Footer";
import styles from "./CupcakesAlwaysAvailable2.module.css";

const CupcakesAlwaysAvailable2 = () => {
  return (
    <div className={styles.cupcakesAlwaysAvailable}>
      <Page />
      <Footer rectangle146="/rectangle-146.svg" />
    </div>
  );
};

export default CupcakesAlwaysAvailable2;
