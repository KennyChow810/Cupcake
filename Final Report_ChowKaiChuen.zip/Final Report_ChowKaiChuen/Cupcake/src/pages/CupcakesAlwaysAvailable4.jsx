import FrameComponent8 from "../components/FrameComponent8";
import Footer from "../components/Footer";
import styles from "./CupcakesAlwaysAvailable4.module.css";

const CupcakesAlwaysAvailable4 = () => {
  return (
    <div className={styles.cupcakesAlwaysAvailable}>
      <FrameComponent8 />
      <Footer rectangle146="/rectangle-146.svg" />
    </div>
  );
};

export default CupcakesAlwaysAvailable4;
