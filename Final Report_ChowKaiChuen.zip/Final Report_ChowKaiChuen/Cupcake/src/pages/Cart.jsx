import Header1 from "../components/Header1";
import ShoppingCart from "../components/ShoppingCart";
import Footer from "../components/Footer";
import styles from "./Cart.module.css";

const Cart = () => {
  return (
    <div className={styles.cart}>
      <Header1 />
      <ShoppingCart />
      <Footer propMarginTop="unset" rectangle146="/rectangle-146.svg" />
    </div>
  );
};

export default Cart;
