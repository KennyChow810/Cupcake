import Header2 from "../components/Header2";
import Footer from "../components/Footer";
import styles from "./CupcakesAlwaysAvailable1.module.css";

const CupcakesAlwaysAvailable1 = () => {
  return (
    <div className={styles.cupcakesAlwaysAvailable}>
      <Header2 />
      <Footer rectangle146="/rectangle-146.svg" />
    </div>
  );
};

export default CupcakesAlwaysAvailable1;
