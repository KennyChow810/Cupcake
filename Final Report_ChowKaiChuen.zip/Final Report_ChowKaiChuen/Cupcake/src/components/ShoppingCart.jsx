import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";
import styles from "./ShoppingCart.module.css";

const ShoppingCart = ({ className = "" }) => {
  const navigate = useNavigate();

  const onArrowImageClick = useCallback(() => {
    navigate("/-cupcakes-always-available");
  }, [navigate]);

  return (
    <section className={[styles.shoppingCart, className].join(" ")}>
      <div className={styles.cartContent}>
        <div className={styles.headerRow}>
          <div className={styles.shoppingNavigation}>
            <img
              className={styles.arrowIcon}
              loading="lazy"
              alt=""
              src="/arrow@2x.png"
              onClick={onArrowImageClick}
            />
            <div className={styles.continueLink}>
              <div
                className={styles.continueShopping}
              >{`Continue Shopping `}</div>
            </div>
          </div>
          <div className={styles.headerRowInner}>
            <div className={styles.frameChild} />
          </div>
        </div>
        <div className={styles.cartTitle}>
          <div className={styles.cartHeader}>
            <div className={styles.shoppingCart1}>Shopping cart</div>
            <div className={styles.youHave3}>You have 3 item in your cart</div>
          </div>
        </div>
        <div className={styles.cartItem}>
          <div className={styles.itemDetails}>
            <img
              className={styles.image19Icon}
              loading="lazy"
              alt=""
              src="/image-19@2x.png"
            />
            <div className={styles.rectangleParent}>
              <div className={styles.frameItem} />
              <div className={styles.vanillaChocolate}>vanilla chocolate</div>
              <div className={styles.quantityAdjusterWrapper}>
                <div className={styles.quantityAdjuster}>
                  <div className={styles.adjusterContainer}>
                    <div className={styles.buttonContainer}>
                      <div className={styles.plusMinusButtons}>
                        <div className={styles.plusButton}>1</div>
                        <div className={styles.plusMinusButtonsChild} />
                      </div>
                    </div>
                    <img
                      className={styles.adjusterContainerChild}
                      loading="lazy"
                      alt=""
                      src="/group-4.svg"
                    />
                  </div>
                  <div className={styles.quantityDisplay}>
                    <div className={styles.quantityValue}>$3.75</div>
                  </div>
                  <div className={styles.removeItem}>
                    <img
                      className={styles.trashCanIcon}
                      loading="lazy"
                      alt=""
                      src="/trash-can@2x.png"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.cartItem}>
          <div className={styles.itemDetailsTwo}>
            <div className={styles.itemDetailsTwoChild} />
            <div className={styles.vanillaChocolate}>chocolate caramel</div>
            <div className={styles.quantityAdjusterTwoWrapper}>
              <div className={styles.quantityAdjuster}>
                <div className={styles.adjusterContainer}>
                  <div className={styles.buttonContainerTwo}>
                    <div className={styles.plusMinusButtonsTwo}>
                      <div className={styles.plusMinusButtonsChild} />
                      <div className={styles.plusButtonTwo}>1</div>
                    </div>
                  </div>
                  <img
                    className={styles.adjusterContainerChild}
                    loading="lazy"
                    alt=""
                    src="/group-5.svg"
                  />
                </div>
                <div className={styles.quantityDisplayTwo}>
                  <div className={styles.quantityValue}>$3.75</div>
                </div>
                <img
                  className={styles.trashCanIcon1}
                  alt=""
                  src="/trash-can-1@2x.png"
                />
              </div>
            </div>
            <img
              className={styles.image21Icon}
              loading="lazy"
              alt=""
              src="/image-21@2x.png"
            />
          </div>
        </div>
        <div className={styles.cartItemThree}>
          <div className={styles.frameItem} />
          <div className={styles.itemDetailsThree}>
            <img
              className={styles.image23Icon}
              loading="lazy"
              alt=""
              src="/image-23@2x.png"
            />
            <div className={styles.flavorNameThree}>
              <div className={styles.chocolateCarmelIi}>
                chocolate carmel II
              </div>
            </div>
          </div>
          <div className={styles.quantityAdjusterThreeWrapper}>
            <div className={styles.quantityAdjuster}>
              <div className={styles.adjusterContainer}>
                <div className={styles.buttonContainerThree}>
                  <div className={styles.plusMinusButtonsThree}>
                    <div className={styles.plusButton}>1</div>
                    <div className={styles.plusMinusButtonsChild} />
                  </div>
                </div>
                <img
                  className={styles.adjusterContainerChild}
                  loading="lazy"
                  alt=""
                  src="/group-4.svg"
                />
              </div>
              <div className={styles.quantityDisplayTwo}>
                <div className={styles.quantityValue}>$3.75</div>
              </div>
              <img
                className={styles.trashCanIcon2}
                alt=""
                src="/trash-can@2x.png"
              />
            </div>
          </div>
        </div>
        <div className={styles.cartActions}>
          <div className={styles.actionButtons}>
            <div className={styles.clearButton}>
              <img
                className={styles.clearButtonChild}
                alt=""
                src="/rectangle-162.svg"
              />
              <a className={styles.clearAll}>Clear All</a>
            </div>
            <div className={styles.totalParent}>
              <div className={styles.total}>Total:</div>
              <div className={styles.totalLabels}>$11.25</div>
              <div className={styles.checkoutButton}>
                <img
                  className={styles.clearButtonChild}
                  alt=""
                  src="/rectangle-162.svg"
                />
                <div className={styles.checkout}>Checkout</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

ShoppingCart.propTypes = {
  className: PropTypes.string,
};

export default ShoppingCart;
