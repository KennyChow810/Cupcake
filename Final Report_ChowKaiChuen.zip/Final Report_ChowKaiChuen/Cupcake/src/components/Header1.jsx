import { useCallback } from "react";
import FrameComponent from "./FrameComponent";
import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";
import styles from "./Header1.module.css";

const Header1 = ({ className = "" }) => {
  const navigate = useNavigate();

  const onCUPCAKESTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available");
  }, [navigate]);

  const onCorporateEventTextClick = useCallback(() => {
    navigate("/corporate-event");
  }, [navigate]);

  const onCustomizationTextClick = useCallback(() => {
    navigate("/customization");
  }, [navigate]);

  const onABOUTUSTextClick = useCallback(() => {
    navigate("/about-us");
  }, [navigate]);

  const onCONTACTTextClick = useCallback(() => {
    navigate("/contact");
  }, [navigate]);

  const onFAQsTextClick = useCallback(() => {
    navigate("/faqs");
  }, [navigate]);

  return (
    <section className={[styles.header, className].join(" ")}>
      <header className={styles.rectangleParent}>
        <div className={styles.frameChild} />
        <FrameComponent hOMEPadding="unset" />
        <div className={styles.optionsRow}>
          <a className={styles.cupcakes} onClick={onCUPCAKESTextClick}>
            CUPCAKES
          </a>
        </div>
        <div className={styles.optionsRow1}>
          <a
            className={styles.corporateEvent}
            onClick={onCorporateEventTextClick}
          >
            corporate event
          </a>
        </div>
        <div className={styles.optionsRow1}>
          <a
            className={styles.corporateEvent}
            onClick={onCustomizationTextClick}
          >
            Customization
          </a>
        </div>
        <div className={styles.navigation}>
          <div className={styles.menuLinks}>
            <nav className={styles.linksRow}>
              <a className={styles.aboutUs} onClick={onABOUTUSTextClick}>
                ABOUT US
              </a>
              <a className={styles.contact} onClick={onCONTACTTextClick}>
                CONTACT
              </a>
              <a className={styles.faqs} onClick={onFAQsTextClick}>
                FAQs
              </a>
            </nav>
            <div className={styles.cartIcon}>
              <div className={styles.iconContainer}>
                <img
                  className={styles.iconContainerChild}
                  loading="lazy"
                  alt=""
                  src="/ellipse-1.svg"
                />
                <div className={styles.cartButton}>
                  <img className={styles.cartIcon1} alt="" src="/cart@2x.png" />
                  <a className={styles.cartCounter}>3</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>
    </section>
  );
};

Header1.propTypes = {
  className: PropTypes.string,
};

export default Header1;
