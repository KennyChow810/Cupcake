import { useMemo } from "react";
import PropTypes from "prop-types";
import styles from "./HalfDozenProduct.module.css";

const HalfDozenProduct = ({
  className = "",
  propGap,
  propMinWidth,
  torontoMothersDayHalfDozen,
  propGap1,
  mothersDayHalfDozen,
  propHeight,
}) => {
  const halfDozenProductStyle = useMemo(() => {
    return {
      gap: propGap,
      minWidth: propMinWidth,
    };
  }, [propGap, propMinWidth]);

  const halfDozenNameStyle = useMemo(() => {
    return {
      gap: propGap1,
    };
  }, [propGap1]);

  const mothersDayHalfStyle = useMemo(() => {
    return {
      height: propHeight,
    };
  }, [propHeight]);

  return (
    <div
      className={[styles.halfDozenProduct, className].join(" ")}
      style={halfDozenProductStyle}
    >
      <img
        className={styles.torontoMothersDayHalfDozenIcon}
        loading="lazy"
        alt=""
        src={torontoMothersDayHalfDozen}
      />
      <div className={styles.halfDozenTitle}>
        <div className={styles.halfDozenName} style={halfDozenNameStyle}>
          <div className={styles.mothersDayHalf} style={mothersDayHalfStyle}>
            {mothersDayHalfDozen}
          </div>
          <div className={styles.halfDozenOptions}>
            <div className={styles.rectangleParent}>
              <div className={styles.frameChild} />
              <div className={styles.halfDozenButtons}>
                <div className={styles.halfDozenButtonsChild} />
                <div className={styles.halfDozenEmpty}>-</div>
              </div>
              <div className={styles.halfDozenQuantityInput}>
                <div className={styles.halfDozenInput}>1</div>
              </div>
              <div className={styles.halfDozenButtons1}>
                <div className={styles.halfDozenButtonsChild} />
                <div className={styles.div}>+</div>
              </div>
            </div>
            <div className={styles.rectangleGroup}>
              <div className={styles.frameItem} />
              <div className={styles.addToCart}>add to cart</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

HalfDozenProduct.propTypes = {
  className: PropTypes.string,
  torontoMothersDayHalfDozen: PropTypes.string,
  mothersDayHalfDozen: PropTypes.string,

  /** Style props */
  propGap: PropTypes.any,
  propMinWidth: PropTypes.any,
  propGap1: PropTypes.any,
  propHeight: PropTypes.any,
};

export default HalfDozenProduct;
