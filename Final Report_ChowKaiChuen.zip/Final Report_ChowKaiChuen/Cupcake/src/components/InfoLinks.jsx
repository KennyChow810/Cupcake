import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";
import styles from "./InfoLinks.module.css";

const InfoLinks = ({ className = "" }) => {
  const navigate = useNavigate();

  const onABOUTUSTextClick = useCallback(() => {
    navigate("/about-us");
  }, [navigate]);

  const onCONTACTTextClick = useCallback(() => {
    navigate("/contact");
  }, [navigate]);

  const onFAQsTextClick = useCallback(() => {
    navigate("/faqs");
  }, [navigate]);

  const onCartIconClick = useCallback(() => {
    navigate("/cart");
  }, [navigate]);

  return (
    <div className={[styles.infoLinks, className].join(" ")}>
      <div className={styles.contactLinks}>
        <nav className={styles.contactOptionsWrapper}>
          <nav className={styles.contactOptions}>
            <a className={styles.aboutUs} onClick={onABOUTUSTextClick}>
              ABOUT US
            </a>
            <a className={styles.contact} onClick={onCONTACTTextClick}>
              CONTACT
            </a>
            <a className={styles.faqs} onClick={onFAQsTextClick}>
              FAQs
            </a>
          </nav>
        </nav>
        <img
          className={styles.cartIcon}
          loading="lazy"
          alt=""
          src="/cart@2x.png"
          onClick={onCartIconClick}
        />
      </div>
    </div>
  );
};

InfoLinks.propTypes = {
  className: PropTypes.string,
};

export default InfoLinks;
