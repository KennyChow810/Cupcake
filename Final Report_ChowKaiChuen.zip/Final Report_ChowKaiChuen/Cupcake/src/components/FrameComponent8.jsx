import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import GroupComponent from "./GroupComponent";
import PropTypes from "prop-types";
import styles from "./FrameComponent8.module.css";

const FrameComponent8 = ({ className = "" }) => {
  const navigate = useNavigate();

  const onCUPCAKESTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available");
  }, [navigate]);

  const onHolidaysTextClick = useCallback(() => {
    navigate("/cupcakes-holidays-mother-day");
  }, [navigate]);

  const onEventTextClick = useCallback(() => {
    navigate("/cupcakes-event");
  }, [navigate]);

  const onChocolateTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available-choclate");
  }, [navigate]);

  const onVanillaTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available-vanilla");
  }, [navigate]);

  const onRedVelvetTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available-red-velvet");
  }, [navigate]);

  const onOthersTextClick = useCallback(() => {
    navigate("/cupcakes-others");
  }, [navigate]);

  return (
    <section className={[styles.frameParent, className].join(" ")}>
      <GroupComponent onCUPCAKESTextClick={onCUPCAKESTextClick} />
      <div className={styles.content}>
        <div className={styles.cupcakesDescriptionParent}>
          <div className={styles.cupcakesDescription}>
            <h1 className={styles.cupcakes}>CUPCAKES</h1>
          </div>
          <div className={styles.productOptions}>
            <div className={styles.availability}>
              <div className={styles.available}>
                <div className={styles.alwaysEvent}>
                  <div className={styles.alwaysHolidays}>
                    <div className={styles.alwaysAvailableParent}>
                      <h1
                        className={styles.alwaysAvailable}
                        onClick={onCUPCAKESTextClick}
                      >
                        always available
                      </h1>
                      <h1
                        className={styles.holidays}
                        onClick={onHolidaysTextClick}
                      >
                        holidays
                      </h1>
                    </div>
                    <h1 className={styles.event} onClick={onEventTextClick}>
                      event
                    </h1>
                  </div>
                </div>
                <div className={styles.each2150}>
                  $3.75 each | $21.50 half dozen | $41.5 dozen
                </div>
              </div>
              <div className={styles.categoriesWrapper}>
                <div className={styles.categories}>
                  <b className={styles.categories1}>CATEGORIES</b>
                  <div className={styles.categoriesList}>
                    <div
                      className={styles.oneDozenAssorted}
                    >{`One dozen assorted box `}</div>
                    <div className={styles.categoriesItems}>
                      <div
                        className={styles.chocolate}
                        onClick={onChocolateTextClick}
                      >
                        Chocolate
                      </div>
                    </div>
                    <div className={styles.categoriesItems}>
                      <div
                        className={styles.vanilla}
                        onClick={onVanillaTextClick}
                      >
                        Vanilla
                      </div>
                    </div>
                    <div className={styles.categoriesItems}>
                      <div
                        className={styles.chocolate}
                        onClick={onRedVelvetTextClick}
                      >
                        Red Velvet
                      </div>
                    </div>
                    <div className={styles.all} onClick={onCUPCAKESTextClick}>
                      ALL
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles.product}>
                <div className={styles.productNameParent}>
                  <div className={styles.productName}>
                    <div className={styles.oneDozenAssorted1}>
                      one dozen assorted box
                    </div>
                  </div>
                  <div className={styles.cartButton}>
                    <div className={styles.rectangleParent}>
                      <div className={styles.frameChild} />
                      <div className={styles.cartButtonSeparator}>
                        <div className={styles.cartButtonSeparatorChild} />
                        <div className={styles.separator}>-</div>
                      </div>
                      <div className={styles.placeholderWrapper}>
                        <div className={styles.placeholder}>1</div>
                      </div>
                      <div className={styles.cartButtonSeparator1}>
                        <div className={styles.cartButtonSeparatorChild} />
                        <div className={styles.div}>+</div>
                      </div>
                    </div>
                    <div className={styles.rectangleGroup}>
                      <div className={styles.frameItem} />
                      <div className={styles.addToCart}>add to cart</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.others}>
              <h1 className={styles.others1} onClick={onOthersTextClick}>
                others
              </h1>
              <div className={styles.assortedImage}>
                <img
                  className={styles.assorteddozen1Icon}
                  loading="lazy"
                  alt=""
                  src="/assorteddozen-1@2x.png"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

FrameComponent8.propTypes = {
  className: PropTypes.string,
};

export default FrameComponent8;
