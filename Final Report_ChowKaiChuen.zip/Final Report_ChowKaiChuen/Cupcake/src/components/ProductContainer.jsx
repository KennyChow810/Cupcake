import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import HalfDozenProduct from "./HalfDozenProduct";
import PropTypes from "prop-types";
import styles from "./ProductContainer.module.css";

const ProductContainer = ({ className = "" }) => {
  const navigate = useNavigate();

  const onAlwaysAvailableTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available");
  }, [navigate]);

  const onEventTextClick = useCallback(() => {
    navigate("/cupcakes-event");
  }, [navigate]);

  const onOthersTextClick = useCallback(() => {
    navigate("/cupcakes-others");
  }, [navigate]);

  const onValentinesDayTextClick = useCallback(() => {
    navigate("/cupcakes-holidays-valentines-day");
  }, [navigate]);

  const onEASTERTextClick = useCallback(() => {
    navigate("/cupcakes-holidays-easter");
  }, [navigate]);

  const onOhCanadaCanadaClick = useCallback(() => {
    navigate("/cupcakes-holidays-oh-canada");
  }, [navigate]);

  const onStPattysDayClick = useCallback(() => {
    navigate("/cupcakes-holidays-st-patty");
  }, [navigate]);

  return (
    <div className={[styles.productContainer, className].join(" ")}>
      <div className={styles.productDetails}>
        <div className={styles.productInfo}>
          <div className={styles.productOptions}>
            <div className={styles.productName}>
              <h1 className={styles.cupcakes}>CUPCAKES</h1>
            </div>
            <div className={styles.formContent}>
              <div className={styles.availableOptions}>
                <h1
                  className={styles.alwaysAvailable}
                  onClick={onAlwaysAvailableTextClick}
                >
                  always available
                </h1>
                <h1 className={styles.holidays}>holidays</h1>
              </div>
              <div className={styles.eventOption}>
                <h1 className={styles.event} onClick={onEventTextClick}>
                  event
                </h1>
              </div>
              <h1 className={styles.others} onClick={onOthersTextClick}>
                others
              </h1>
            </div>
          </div>
          <div className={styles.quantity}>
            <h2 className={styles.each24}>
              $3.75 each | $24 half dozen | $48 dozen
            </h2>
          </div>
        </div>
      </div>
      <div className={styles.categoryItemsParent}>
        <div className={styles.categoryItems}>
          <div className={styles.categoryList}>
            <b className={styles.categories}>CATEGORIES</b>
            <div className={styles.categoryOptions}>
              <div className={styles.mothersDay}>mother’s day</div>
              <div className={styles.categoryNames}>
                <div
                  className={styles.valentinesDay}
                  onClick={onValentinesDayTextClick}
                >
                  Valentine's Day
                </div>
              </div>
              <div className={styles.categoryNames}>
                <div className={styles.easter} onClick={onEASTERTextClick}>
                  EASTER
                </div>
              </div>
              <div className={styles.categoryNames2}>
                <div
                  className={styles.valentinesDay}
                  onClick={onOhCanadaCanadaClick}
                >
                  Oh Canada! Canada Day
                </div>
              </div>
              <div
                className={styles.valentinesDay}
                onClick={onStPattysDayClick}
              >
                St Patty's Day cupcake
              </div>
            </div>
          </div>
        </div>
        <div className={styles.mothersDayProduct}>
          <img
            className={styles.torontoMothersDayDozen1Icon}
            loading="lazy"
            alt=""
            src="/toronto-mothers-day-dozen-1@2x.png"
          />
          <div className={styles.productTitle}>
            <div className={styles.mothersDayDozen}>Mother's Day Dozen</div>
          </div>
          <div className={styles.dozenOptions}>
            <div className={styles.frameParent}>
              <div className={styles.rectangleParent}>
                <div className={styles.frameChild} />
                <div className={styles.dozenButtonLabels}>
                  <div className={styles.dozenButtonLabelsChild} />
                  <div className={styles.emptyLabel}>-</div>
                </div>
                <div className={styles.quantityInput}>
                  <div className={styles.inputPlaceholder}>1</div>
                </div>
                <div className={styles.dozenButtonLabels1}>
                  <div className={styles.dozenButtonLabelsChild} />
                  <div className={styles.div}>+</div>
                </div>
              </div>
              <div className={styles.rectangleGroup}>
                <div className={styles.frameItem} />
                <div className={styles.addToCart}>add to cart</div>
              </div>
            </div>
          </div>
        </div>
        <HalfDozenProduct
          torontoMothersDayHalfDozen="/toronto-mothers-day-half-dozen-1@2x.png"
          mothersDayHalfDozen="Mother's Day Half Dozen"
        />
      </div>
    </div>
  );
};

ProductContainer.propTypes = {
  className: PropTypes.string,
};

export default ProductContainer;
