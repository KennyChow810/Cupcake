import LastNameContact from "./LastNameContact";
import Footer from "./Footer";
import PropTypes from "prop-types";
import styles from "./FrameComponent5.module.css";

const FrameComponent5 = ({ className = "" }) => {
  return (
    <section className={[styles.contactFormContentParent, className].join(" ")}>
      <div className={styles.contactFormContent}>
        <div className={styles.contactFormContentChild} />
        <div className={styles.contactFormHeading}>
          <h2 className={styles.tellUsYour}>
            Tell us your needs and we will contact you asap
          </h2>
        </div>
        <div className={styles.formFields}>
          <div className={styles.rectangleParent}>
            <div className={styles.frameChild} />
            <div className={styles.send}>Send</div>
          </div>
          <div className={styles.nameFields}>
            <div className={styles.firstName}>First Name</div>
            <div className={styles.firstNameField}>
            <input type="text" className={styles.firstNameInput} />
              <div className={styles.emailField}>
                <div className={styles.email}>Email</div>
                <input type="text" className={styles.firstNameInput} />
              </div>
              <div className={styles.message}>Message</div>
            </div>
          </div>
          <LastNameContact />
          <input type="text" className={styles.messageInput} />
        </div>
      </div>
      <Footer propMarginTop="-10px" rectangle146="/rectangle-146.svg" />
    </section>
  );
};

FrameComponent5.propTypes = {
  className: PropTypes.string,
};

export default FrameComponent5;
