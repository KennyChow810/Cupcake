import { useMemo } from "react";
import PropTypes from "prop-types";
import styles from "./ChocolateToffeeElements.module.css";

const ChocolateToffeeElements = ({
  className = "",
  propGap,
  propPadding,
  propAlignSelf,
  propFlex,
  propWidth,
  image27,
  propFlex1,
  propOverflow,
  propWidth1,
  propWidth2,
  propAlignSelf1,
  chocolateToffeeOreo,
  propGap1,
}) => {
  const chocolateToffeeElementsStyle = useMemo(() => {
    return {
      gap: propGap,
      padding: propPadding,
      alignSelf: propAlignSelf,
      flex: propFlex,
    };
  }, [propGap, propPadding, propAlignSelf, propFlex]);

  const chocolateToffeeImagesStyle = useMemo(() => {
    return {
      width: propWidth,
    };
  }, [propWidth]);

  const image27IconStyle = useMemo(() => {
    return {
      flex: propFlex1,
      overflow: propOverflow,
      width: propWidth1,
    };
  }, [propFlex1, propOverflow, propWidth1]);

  const chocolateToffeeNamesStyle = useMemo(() => {
    return {
      width: propWidth2,
      alignSelf: propAlignSelf1,
    };
  }, [propWidth2, propAlignSelf1]);

  const frameDiv10Style = useMemo(() => {
    return {
      gap: propGap1,
    };
  }, [propGap1]);

  return (
    <div
      className={[styles.chocolateToffeeElements, className].join(" ")}
      style={chocolateToffeeElementsStyle}
    >
      <div
        className={styles.chocolateToffeeImages}
        style={chocolateToffeeImagesStyle}
      >
        <img
          className={styles.image27Icon}
          loading="lazy"
          alt=""
          src={image27}
          style={image27IconStyle}
        />
      </div>
      <div className={styles.chocolateToffeeDetails}>
        <div
          className={styles.chocolateToffeeNames}
          style={chocolateToffeeNamesStyle}
        >
          <div className={styles.chocolateToffeeOreoContainer}>
            <p className={styles.chocolateToffeeOreo}>{chocolateToffeeOreo}</p>
          </div>
        </div>
        <div className={styles.frameParent} style={frameDiv10Style}>
          <div className={styles.rectangleParent}>
            <div className={styles.frameChild} />
            <div className={styles.chocolateToffeeAddFirst}>
              <div className={styles.chocolateToffeeAddFirstChild} />
              <div className={styles.chocolateToffeeAdd}>-</div>
            </div>
            <div className={styles.chocolateToffeeAddSecond}>
              <div className={styles.chocolateToffeeAdd1}>1</div>
            </div>
            <div className={styles.chocolateToffeeAddThird}>
              <div className={styles.chocolateToffeeAddFirstChild} />
              <div className={styles.chocolateToffeeAdd2}>+</div>
            </div>
          </div>
          <div className={styles.rectangleGroup}>
            <div className={styles.frameItem} />
            <div className={styles.addToCart}>add to cart</div>
          </div>
        </div>
      </div>
    </div>
  );
};

ChocolateToffeeElements.propTypes = {
  className: PropTypes.string,
  image27: PropTypes.string,
  chocolateToffeeOreo: PropTypes.string,

  /** Style props */
  propGap: PropTypes.any,
  propPadding: PropTypes.any,
  propAlignSelf: PropTypes.any,
  propFlex: PropTypes.any,
  propWidth: PropTypes.any,
  propFlex1: PropTypes.any,
  propOverflow: PropTypes.any,
  propWidth1: PropTypes.any,
  propWidth2: PropTypes.any,
  propAlignSelf1: PropTypes.any,
  propGap1: PropTypes.any,
};

export default ChocolateToffeeElements;
