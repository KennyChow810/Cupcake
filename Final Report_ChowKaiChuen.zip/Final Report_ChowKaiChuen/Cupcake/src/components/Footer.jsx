import { useMemo } from "react";
import PropTypes from "prop-types";
import styles from "./Footer.module.css";

const Footer = ({ className = "", propMarginTop, rectangle146 }) => {
  const footerStyle = useMemo(() => {
    return {
      marginTop: propMarginTop,
    };
  }, [propMarginTop]);

  return (
    <footer
      className={[styles.footer, className].join(" ")}
      style={footerStyle}
    >
      <img className={styles.footerChild} alt="" src={rectangle146} />
      <div className={styles.openingHoursMonSatContainer}>
        <p className={styles.openingHours}>OPENING HOURS</p>
        <p className={styles.openingHours}>&nbsp;</p>
        <p className={styles.monSat700amTo}>MON-SAT: 7:00am to 10:00Pm</p>
        <p className={styles.sunday7}>
          sunday: 7 a.m. to 10 p.m. (no pick-ups, deliveries for 2doz or more)
        </p>
        <p className={styles.monSat700amTo}>&nbsp;</p>
        <p className={styles.openingHours}>{` `}</p>
      </div>
      <div className={styles.contactNorthAmericaContainer}>
        <p className={styles.openingHours}>{`contact 
`}</p>
        <p className={styles.openingHours}>North America: +1-877-334-9468</p>
        <p className={styles.openingHours}>&nbsp;</p>
        <p className={styles.openingHours}>
          Outside of North Am: +001-647-478-9464
        </p>
        <p className={styles.openingHours}>&nbsp;</p>
        <p className={styles.openingHours}>
          Local Toronto and GTA: 647-478-9464
        </p>
        <p className={styles.openingHours}>&nbsp;</p>
        <p className={styles.openingHours}>Email: inquiry@torontocupcake.com</p>
      </div>
      <div className={styles.menu} />
    </footer>
  );
};

Footer.propTypes = {
  className: PropTypes.string,
  rectangle146: PropTypes.string,

  /** Style props */
  propMarginTop: PropTypes.any,
};

export default Footer;
