import PropTypes from "prop-types";
import styles from "./CorporateEventHero.module.css";

const CorporateEventHero = ({ className = "" }) => {
  return (
    <section className={[styles.corporateEventHero, className].join(" ")}>
      <div className={styles.heroContent}>
        <div className={styles.heroTitleWrapper}>
          <div className={styles.heroTitle}>
            <h1 className={styles.corporateEvent}>cORPORATE EVENT</h1>
            <div className={styles.heroImage}>
              <img
                className={styles.corpeventscollage1Icon}
                loading="lazy"
                alt=""
                src="/corpeventscollage-1@2x.png"
              />
            </div>
          </div>
        </div>
        <div className={styles.welcomeThankYouContainer}>
          <p className={styles.fromProductbrandLaunch}>
            From Product/Brand Launch to Customer Appreciation, Toronto Cupcake
            is able to provide you custom decorating to match that winning
            campaign.
          </p>
          <p className={styles.fromProductbrandLaunch}>
            Our Graphics Department will work with you to reproduce Logos,
            Icons, Slogans , etc on an edible fondant disc or hand pressed
            lettering on a fondant disc. Our frostings can be made to mimic your
            theme colours or to use as a neutral backdrop.
          </p>
          <p className={styles.fromProductbrandLaunch}>
            Our graphics are crystal clear and because we mount them on fondant
            they look great and are edible!
          </p>
          <p className={styles.fromProductbrandLaunch}>
            You can send us your graphics in almost any format (jpg, png, gif,
            bmp, svg, etc) and we will take it from there.
          </p>
          <p className={styles.fromProductbrandLaunch}>
            We will work with you on special delivery requests and packaging if
            needed.
          </p>
          <p className={styles.fromProductbrandLaunch}>
            We will deliver your marketing materials along with our cupcakes.
          </p>
          <p className={styles.fromProductbrandLaunch}>&nbsp;</p>
          <p className={styles.fromProductbrandLaunch}>
            To contact us by phone please call:
          </p>
          <p className={styles.fromProductbrandLaunch}>
            North America: +1-877-334-9468
          </p>
          <p className={styles.fromProductbrandLaunch}>
            Outside of North Am: +001-647-478-9464
          </p>
          <p className={styles.fromProductbrandLaunch}>
            Email us at: inquiry@torontocupcake.com with any type of question
            regarding your marketing or in-house campaign.
          </p>
        </div>
      </div>
    </section>
  );
};

CorporateEventHero.propTypes = {
  className: PropTypes.string,
};

export default CorporateEventHero;
