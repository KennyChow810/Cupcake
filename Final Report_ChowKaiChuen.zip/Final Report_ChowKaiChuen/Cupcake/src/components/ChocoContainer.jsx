import { useMemo } from "react";
import PropTypes from "prop-types";
import styles from "./ChocoContainer.module.css";

const ChocoContainer = ({
  className = "",
  image31,
  propAlignSelf,
  propWidth,
  chocolateCoconut,
  chocolateCoconut1,
  propMarginLeft,
  propGap,
}) => {
  const chocoTypeStyle = useMemo(() => {
    return {
      alignSelf: propAlignSelf,
      width: propWidth,
    };
  }, [propAlignSelf, propWidth]);

  const chocolateCoconutStyle = useMemo(() => {
    return {
      marginLeft: propMarginLeft,
    };
  }, [propMarginLeft]);

  const chocoQuantityStyle = useMemo(() => {
    return {
      gap: propGap,
    };
  }, [propGap]);

  return (
    <div className={[styles.chocoContainer, className].join(" ")}>
      <div className={styles.chocoName}>
        <img
          className={styles.image31Icon}
          loading="lazy"
          alt=""
          src={image31}
        />
      </div>
      <div className={styles.chocoFlavor}>
        <div className={styles.chocoType} style={chocoTypeStyle}>
          <div className={styles.chocoTypes}>
            <div className={styles.chocolateCoconut}>{chocolateCoconut}</div>
            <div
              className={styles.chocolateCoconut1}
              style={chocolateCoconutStyle}
            >
              {chocolateCoconut1}
            </div>
          </div>
        </div>
        <div className={styles.chocoQuantity} style={chocoQuantityStyle}>
          <div className={styles.rectangleParent}>
            <div className={styles.frameChild} />
            <div className={styles.parent}>
              <div className={styles.div}>1</div>
              <div className={styles.rectangleGroup}>
                <div className={styles.frameItem} />
                <div className={styles.div1}>-</div>
              </div>
              <div className={styles.rectangleGroup}>
                <div className={styles.frameItem} />
                <div className={styles.div2}>+</div>
              </div>
              <div className={styles.rectangleDiv} />
              <div className={styles.chocoValue}>
                <div className={styles.chocoValueChild} />
                <div className={styles.chocoAdd}>-</div>
              </div>
              <div className={styles.chocoButton}>
                <div className={styles.chocoCart}>1</div>
              </div>
              <div className={styles.chocoValue1}>
                <div className={styles.chocoValueChild} />
                <div className={styles.div3}>+</div>
              </div>
            </div>
          </div>
          <div className={styles.groupDiv}>
            <div className={styles.frameChild1} />
            <div className={styles.addToCartParent}>
              <div className={styles.addToCart}>add to cart</div>
              <div className={styles.frameChild1} />
              <div className={styles.addToCart1}>add to cart</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

ChocoContainer.propTypes = {
  className: PropTypes.string,
  image31: PropTypes.string,
  chocolateCoconut: PropTypes.string,
  chocolateCoconut1: PropTypes.string,

  /** Style props */
  propAlignSelf: PropTypes.any,
  propWidth: PropTypes.any,
  propMarginLeft: PropTypes.any,
  propGap: PropTypes.any,
};

export default ChocoContainer;
