  import { useCallback } from "react";
  import { useNavigate } from "react-router-dom";
  import InfoLinks from "./InfoLinks";
  import PropTypes from "prop-types";
  import styles from "./GroupComponent1.module.css";

  const GroupComponent1 = ({ className = "" }) => {
    const navigate = useNavigate();

    const onCUPCAKESTextClick = useCallback(() => {
      navigate("/-cupcakes-always-available");
    }, [navigate]);

    const onCorporateEventTextClick = useCallback(() => {
      navigate("/corporate-event");
    }, [navigate]);

    const onCustomizationTextClick = useCallback(() => {
      navigate("/customization");
    }, [navigate]);

    return (
      <header className={[styles.rectangleParent, className].join(" ")}>
        <div className={styles.frameChild} />
        <div className={styles.torontoLogoParent}>
          <img
            className={styles.torontoLogoIcon}
            loading="lazy"
            alt=""
            src="/toronto-logo@2x.png"
          />
          <div className={styles.navigationBottom}>
            <div className={styles.homeLink}>
              <div className={styles.homeWrapper}>
                <a className={styles.home}>HOME</a>
              </div>
              <div className={styles.navLinkSeparator} />
            </div>
          </div>
        </div>
        <div className={styles.cupcakesOptions}>
          <a className={styles.cupcakes} onClick={onCUPCAKESTextClick}>
            CUPCAKES
          </a>
        </div>
        <div className={styles.cupcakesOptions1}>
          <a
            className={styles.corporateEvent}
            onClick={onCorporateEventTextClick}
          >
            corporate event
          </a>
        </div>
        <div className={styles.cupcakesOptions1}>
          <a className={styles.corporateEvent} onClick={onCustomizationTextClick}>
            Customization
          </a>
        </div>
        <InfoLinks />
      </header>
    );
  };

  GroupComponent1.propTypes = {
    className: PropTypes.string,
  };

  export default GroupComponent1;
