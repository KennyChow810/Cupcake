import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import ProductRowOne from "./ProductRowOne";
import ProductImagesTwo from "./ProductImagesTwo";
import CoconutImage from "./CoconutImage";
import ChocoContainer from "./ChocoContainer";
import CaramelTwoImage from "./CaramelTwoImage";
import LemonTypes from "./LemonTypes";
import ChocolateToffeeElements from "./ChocolateToffeeElements";
import PropTypes from "prop-types";
import styles from "./CategoryItems.module.css";

const CategoryItems = ({ className = "" }) => {
  const navigate = useNavigate();

  const onOneDozenAssortedClick = useCallback(() => {
    navigate("/-cupcakes-always-available-one-dozen-assorted-box");
  }, [navigate]);

  const onChocolateTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available-choclate");
  }, [navigate]);

  const onVanillaTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available-vanilla");
  }, [navigate]);

  const onRedVelvetTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available-red-velvet");
  }, [navigate]);

  return (
    <div className={[styles.categoryItems, className].join(" ")}>
      <div className={styles.categoryContainerParent}>
        <div className={styles.categoryContainer}>
          <div className={styles.categoryTitle}>
            <b className={styles.categories}>CATEGORIES</b>
            <div className={styles.categoryFlavors}>
              <div
                className={styles.oneDozenAssorted}
                onClick={onOneDozenAssortedClick}
              >{`One dozen assorted box `}</div>
              <div className={styles.flavorOptions}>
                <div
                  className={styles.oneDozenAssorted}
                  onClick={onChocolateTextClick}
                >
                  Chocolate
                </div>
              </div>
              <div className={styles.flavorOptions}>
                <div className={styles.vanilla} onClick={onVanillaTextClick}>
                  Vanilla
                </div>
              </div>
              <div className={styles.flavorOptions}>
                <div
                  className={styles.oneDozenAssorted}
                  onClick={onRedVelvetTextClick}
                >
                  Red Velvet
                </div>
              </div>
              <div className={styles.all}>ALL</div>
            </div>
          </div>
        </div>
        <div className={styles.productGrid}>
          <div className={styles.productRows}>
            <ProductRowOne
              image19="/image-19@2x.png"
              vanillaChocolate="vanilla chocolate"
            />
            <ProductRowOne
              propPadding="unset"
              propGap="2px"
              propAlignSelf="unset"
              propWidth="178px"
              image19="/image-20@2x.png"
              propWidth1="unset"
              propFlex="1"
              propOverflow="hidden"
              vanillaChocolate="vanilla chocolate ganache"
              propAlignSelf1="stretch"
              propWidth2="unset"
              propWidth3="186.9px"
              propAlignSelf2="unset"
            />
            <div className={styles.productTwo}>
              <div className={styles.productImageTwo}>
                <img
                  className={styles.image32Icon}
                  alt=""
                  src="/image-32@2x.png"
                />
              </div>
              <div className={styles.chocolatePeanutButter}>
                chocolate peanut butter
              </div>
              <div className={styles.productDetailsTwo}>
                <div className={styles.productActionsTwo}>
                  <div className={styles.rectangleParent}>
                    <div className={styles.frameChild} />
                    <div className={styles.quantityTwo}>
                      <div className={styles.quantityTwoChild} />
                      <div className={styles.quantityValuesTwo}>-</div>
                    </div>
                    <div className={styles.priceTwo}>
                      <div className={styles.priceValuesTwo}>1</div>
                    </div>
                    <div className={styles.quantityTwo1}>
                      <div className={styles.quantityTwoChild} />
                      <div className={styles.div}>+</div>
                    </div>
                  </div>
                  <div className={styles.rectangleGroup}>
                    <div className={styles.frameItem} />
                    <div className={styles.addToCart}>add to cart</div>
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.productThree}>
              <div className={styles.productImageThree}>
                <img
                  className={styles.image28Icon}
                  loading="lazy"
                  alt=""
                  src="/image-28@2x.png"
                />
              </div>
              <div className={styles.productDetailsThree}>
                <div className={styles.chocolateHazelnut}>
                  <div className={styles.chocolateHazelnut1}>
                    chocolate hazelnut
                  </div>
                  <div className={styles.chocolateHazelnut2}>
                    chocolate hazelnut
                  </div>
                </div>
                <div className={styles.productActionsThree}>
                  <div className={styles.productActionsTwo}>
                    <div className={styles.rectangleContainer}>
                      <div className={styles.frameInner} />
                      <div className={styles.parent}>
                        <div className={styles.div1}>1</div>
                        <div className={styles.frameDiv}>
                          <div className={styles.rectangleDiv} />
                          <div className={styles.div2}>-</div>
                        </div>
                        <div className={styles.frameDiv}>
                          <div className={styles.rectangleDiv} />
                          <div className={styles.div3}>+</div>
                        </div>
                        <div className={styles.frameChild} />
                        <div className={styles.quantityTwo}>
                          <div className={styles.quantityTwoChild} />
                          <div className={styles.quantityValuesThree}>-</div>
                        </div>
                        <div className={styles.priceTwo}>
                          <div className={styles.priceValuesThree}>1</div>
                        </div>
                        <div className={styles.quantityTwo1}>
                          <div className={styles.quantityTwoChild} />
                          <div className={styles.div4}>+</div>
                        </div>
                      </div>
                    </div>
                    <div className={styles.groupDiv}>
                      <div className={styles.frameItem} />
                      <div className={styles.addToCartParent}>
                        <div className={styles.addToCart1}>add to cart</div>
                        <div className={styles.frameItem} />
                        <div className={styles.addToCart}>add to cart</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <ProductRowOne
              propPadding="0px 0px 27px"
              propGap="6px"
              propAlignSelf="unset"
              propWidth="unset"
              image19="/image-36@2x.png"
              propWidth1="152.4px"
              propFlex="unset"
              propOverflow="unset"
              vanillaChocolate="hummingbird"
              propAlignSelf1="stretch"
              propWidth2="unset"
              propWidth3="186.9px"
              propAlignSelf2="unset"
            />
            <ProductRowOne
              propPadding="unset"
              propGap="unset"
              propAlignSelf="unset"
              propWidth="185.3px"
              image19="/image-40@2x.png"
              propWidth1="unset"
              propFlex="1"
              propOverflow="hidden"
              vanillaChocolate="chocolate vanilla choclate ganache"
              propAlignSelf1="stretch"
              propWidth2="unset"
              propWidth3="186.9px"
              propAlignSelf2="unset"
            />
          </div>
          <div className={styles.productRowTwo}>
            <ProductImagesTwo
              image21="/image-21@2x.png"
              chocolateCaramel="chocolate caramel"
            />
            <ProductImagesTwo
              propPadding="unset"
              propGap="unset"
              propWidth="148.1px"
              propAlignSelf="unset"
              image21="/image-221@2x.png"
              propMixBlendMode="unset"
              chocolateCaramel="vanilla caramel"
            />
            <CoconutImage
              image34="/image-341@2x.png"
              vanillaCoconut="vanilla coconut"
            />
            <ChocoContainer
              image31="/image-311@2x.png"
              chocolateCoconut="chocolate coconut"
              chocolateCoconut1="chocolate coconut"
            />
            <ProductImagesTwo
              propPadding="0px 0px 29px"
              propGap="4px"
              propWidth="161.8px"
              propAlignSelf="unset"
              image21="/image-371@2x.png"
              propMixBlendMode="multiply"
              chocolateCaramel="red velvet fudge"
            />
            <div className={styles.ganacheType}>
              <img
                className={styles.image41Icon}
                loading="lazy"
                alt=""
                src="/image-411@2x.png"
              />
              <div className={styles.ganacheOptions}>
                <div className={styles.ganacheQuantity}>
                  <div className={styles.chocolateChocolateGanache}>
                    chocolate chocolate ganache
                  </div>
                </div>
                <div className={styles.ganacheIncrement}>
                  <div className={styles.rectangleParent}>
                    <div className={styles.frameChild} />
                    <div className={styles.quantityTwo}>
                      <div className={styles.quantityTwoChild} />
                      <div className={styles.quantityValuesTwo}>-</div>
                    </div>
                    <div className={styles.priceTwo}>
                      <div className={styles.priceValuesTwo}>1</div>
                    </div>
                    <div className={styles.quantityTwo1}>
                      <div className={styles.quantityTwoChild} />
                      <div className={styles.div}>+</div>
                    </div>
                  </div>
                  <div className={styles.rectangleGroup}>
                    <div className={styles.frameItem} />
                    <div className={styles.addToCart}>add to cart</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className={styles.lemonType}>
            <CaramelTwoImage image23="/image-23@2x.png" />
            <LemonTypes
              image24="/image-24@2x.png"
              lemonVanilla="lemon vanilla"
            />
            <div className={styles.doubleChocolateName}>
              <img
                className={styles.image35Icon}
                loading="lazy"
                alt=""
                src="/image-35@2x.png"
              />
            </div>
            <div className={styles.doubleChocolateType}>
              <div className={styles.doubleChocolateOptions}>
                <div className={styles.chocolateChocolate}>
                  chocolate chocolate
                </div>
              </div>
              <div className={styles.doubleChocolatePrice}>
                <div className={styles.rectangleParent4}>
                  <div className={styles.frameChild} />
                  <div className={styles.quantityTwo}>
                    <div className={styles.quantityTwoChild} />
                    <div className={styles.quantityValuesTwo}>-</div>
                  </div>
                  <div className={styles.priceTwo}>
                    <div className={styles.priceValuesTwo}>1</div>
                  </div>
                  <div className={styles.quantityTwo1}>
                    <div className={styles.quantityTwoChild} />
                    <div className={styles.div}>+</div>
                  </div>
                </div>
                <div className={styles.rectangleGroup}>
                  <div className={styles.frameItem} />
                  <div className={styles.addToCart}>add to cart</div>
                </div>
              </div>
            </div>
            <div className={styles.vanillaChocolateName}>
              <div className={styles.vanillaChocolateFlavor}>
                <img
                  className={styles.image35Icon}
                  alt=""
                  src="/image-29@2x.png"
                />
              </div>
              <div className={styles.chocolateVanillaContainer}>
                <div className={styles.doubleChocolateOptions}>
                  <div className={styles.chocolateVanillaNameBlock}>
                    <div className={styles.chocolateVanilla}>
                      chocolate vanilla
                    </div>
                    <div className={styles.chocolateVanilla1}>
                      chocolate vanilla
                    </div>
                  </div>
                </div>
                <div className={styles.doubleChocolatePrice}>
                  <div className={styles.rectangleContainer}>
                    <div className={styles.frameInner} />
                    <div className={styles.group}>
                      <div className={styles.div7}>1</div>
                      <div className={styles.rectangleParent7}>
                        <div className={styles.rectangleDiv} />
                        <div className={styles.div8}>-</div>
                      </div>
                      <div className={styles.rectangleParent7}>
                        <div className={styles.rectangleDiv} />
                        <div className={styles.div9}>+</div>
                      </div>
                      <div className={styles.frameInner} />
                      <div className={styles.container}>
                        <div className={styles.div7}>1</div>
                        <div className={styles.rectangleParent7}>
                          <div className={styles.rectangleDiv} />
                          <div className={styles.div8}>-</div>
                        </div>
                        <div className={styles.rectangleParent7}>
                          <div className={styles.rectangleDiv} />
                          <div className={styles.div9}>+</div>
                        </div>
                        <div className={styles.frameInner} />
                        <div className={styles.parent1}>
                          <div className={styles.div1}>1</div>
                          <div className={styles.frameDiv}>
                            <div className={styles.rectangleDiv} />
                            <div className={styles.div2}>-</div>
                          </div>
                          <div className={styles.frameDiv}>
                            <div className={styles.rectangleDiv} />
                            <div className={styles.div3}>+</div>
                          </div>
                          <div className={styles.frameChild} />
                          <div className={styles.quantityTwo}>
                            <div className={styles.quantityTwoChild} />
                            <div className={styles.quantityValuesThree}>-</div>
                          </div>
                          <div className={styles.priceTwo}>
                            <div className={styles.priceValuesThree}>1</div>
                          </div>
                          <div className={styles.quantityTwo1}>
                            <div className={styles.quantityTwoChild} />
                            <div className={styles.div4}>+</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className={styles.groupDiv}>
                    <div className={styles.frameItem} />
                    <div className={styles.addToCartParent}>
                      <div className={styles.addToCart1}>add to cart</div>
                      <div className={styles.frameItem} />
                      <div className={styles.addToCart}>add to cart</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <LemonTypes
              propPadding="0px 0px 53.7px"
              propGap="unset"
              propWidth="unset"
              propAlignSelf="stretch"
              image24="/image-38@2x.png"
              propMixBlendMode="multiply"
              propGap1="17px"
              propWidth1="154.4px"
              propAlignSelf1="unset"
              lemonVanilla="hot fudge sundae"
            />
            <LemonTypes
              propPadding="unset"
              propGap="unset"
              propWidth="153.4px"
              propAlignSelf="unset"
              image24="/image-42@2x.png"
              propMixBlendMode="unset"
              propGap1="17.2px"
              propWidth1="163.3px"
              propAlignSelf1="unset"
              lemonVanilla="chocolate mocha"
            />
          </div>
          <div className={styles.chocolateToffeeContainer}>
            <ChocolateToffeeElements
              image27="/image-27@2x.png"
              chocolateToffeeOreo="chocolate toffee oreo"
            />
            <ChocolateToffeeElements
              propGap="unset"
              propPadding="unset"
              propAlignSelf="stretch"
              propFlex="unset"
              propWidth="unset"
              image27="/image-26@2x.png"
              propFlex1="unset"
              propOverflow="unset"
              propWidth1="144.9px"
              propWidth2="unset"
              propAlignSelf1="stretch"
              chocolateToffeeOreo="chocolate oreo"
              propGap1="15.3px"
            />
            <CoconutImage
              propAlignSelf="stretch"
              propWidth="unset"
              image34="/image-33@2x.png"
              propMixBlendMode="unset"
              propAlignSelf1="unset"
              propWidth1="151.8px"
              vanillaCoconut="red velvet"
              propGap="15.3px"
            />
            <ChocoContainer
              image31="/image-30@2x.png"
              propAlignSelf="unset"
              propWidth="151.8px"
              chocolateCoconut="vanilla vanilla"
              chocolateCoconut1="vanilla vanilla"
              propMarginLeft="-121px"
              propGap="15.3px"
            />
            <div className={styles.redVelvetRaspberryContainer}>
              <img
                className={styles.image39Icon}
                loading="lazy"
                alt=""
                src="/image-39@2x.png"
              />
              <div className={styles.redVelvetRaspberryDetails}>
                <div className={styles.redVelvetRaspberryName}>
                  <div className={styles.redVelvetRaspberryContainer1}>
                    <p className={styles.redVelvetRaspberry}>
                      red velvet raspberry
                    </p>
                  </div>
                </div>
                <div className={styles.redVelvetRaspberryActions}>
                  <div className={styles.rectangleParent}>
                    <div className={styles.frameChild} />
                    <div className={styles.quantityTwo}>
                      <div className={styles.quantityTwoChild} />
                      <div className={styles.quantityValuesTwo}>-</div>
                    </div>
                    <div className={styles.priceTwo}>
                      <div className={styles.priceValuesTwo}>1</div>
                    </div>
                    <div className={styles.quantityTwo1}>
                      <div className={styles.quantityTwoChild} />
                      <div className={styles.div}>+</div>
                    </div>
                  </div>
                  <div className={styles.rectangleGroup}>
                    <div className={styles.frameItem} />
                    <div className={styles.addToCart}>add to cart</div>
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.vanillaStrawberryContainer}>
              <img
                className={styles.image43Icon}
                loading="lazy"
                alt=""
                src="/image-43@2x.png"
              />
              <div className={styles.ganacheOptions}>
                <div className={styles.vanillaStrawberryNameBlock}>
                  <div className={styles.vanillaStrawberry}>
                    <p className={styles.redVelvetRaspberry}>
                      vanilla strawberry
                    </p>
                  </div>
                </div>
                <div className={styles.vanillaStrawberryActions}>
                  <div className={styles.rectangleParent}>
                    <div className={styles.frameChild} />
                    <div className={styles.quantityTwo}>
                      <div className={styles.quantityTwoChild} />
                      <div className={styles.quantityValuesTwo}>-</div>
                    </div>
                    <div className={styles.priceTwo}>
                      <div className={styles.priceValuesTwo}>1</div>
                    </div>
                    <div className={styles.quantityTwo1}>
                      <div className={styles.quantityTwoChild} />
                      <div className={styles.div}>+</div>
                    </div>
                  </div>
                  <div className={styles.rectangleGroup}>
                    <div className={styles.frameItem} />
                    <div className={styles.addToCart}>add to cart</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

CategoryItems.propTypes = {
  className: PropTypes.string,
};

export default CategoryItems;
