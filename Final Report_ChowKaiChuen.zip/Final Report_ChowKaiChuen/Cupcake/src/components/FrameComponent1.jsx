import { useMemo } from "react";
import PropTypes from "prop-types";
import styles from "./FrameComponent1.module.css";

const FrameComponent1 = ({
  className = "",
  propWidth,
  propGap,
  propAlignSelf,
  propAlignSelf1,
  propWidth1,
  stpattysday1,
  propHeight,
  propMixBlendMode,
  propGap1,
  stPattysDayCupcake,
  propHeight1,
  propDisplay,
  propGap2,
}) => {
  const frameDiv6Style = useMemo(() => {
    return {
      width: propWidth,
      gap: propGap,
      alignSelf: propAlignSelf,
    };
  }, [propWidth, propGap, propAlignSelf]);

  const frameDiv7Style = useMemo(() => {
    return {
      alignSelf: propAlignSelf1,
      width: propWidth1,
    };
  }, [propAlignSelf1, propWidth1]);

  const stpattysday1IconStyle = useMemo(() => {
    return {
      height: propHeight,
      mixBlendMode: propMixBlendMode,
    };
  }, [propHeight, propMixBlendMode]);

  const frameDiv8Style = useMemo(() => {
    return {
      gap: propGap1,
    };
  }, [propGap1]);

  const stPattysDayStyle = useMemo(() => {
    return {
      height: propHeight1,
      display: propDisplay,
    };
  }, [propHeight1, propDisplay]);

  const frameDiv9Style = useMemo(() => {
    return {
      gap: propGap2,
    };
  }, [propGap2]);

  return (
    <div
      className={[styles.frameParent, className].join(" ")}
      style={frameDiv6Style}
    >
      <div className={styles.stpattysday1Wrapper} style={frameDiv7Style}>
        <img
          className={styles.stpattysday1Icon}
          loading="lazy"
          alt=""
          src={stpattysday1}
          style={stpattysday1IconStyle}
        />
      </div>
      <div className={styles.stPattysDayCupcakeParent} style={frameDiv8Style}>
        <div className={styles.stPattysDay} style={stPattysDayStyle}>
          {stPattysDayCupcake}
        </div>
        <div className={styles.frameWrapper}>
          <div className={styles.frameGroup} style={frameDiv9Style}>
            <div className={styles.rectangleParent}>
              <div className={styles.frameChild} />
              <div className={styles.rectangleGroup}>
                <div className={styles.frameItem} />
                <div className={styles.addToCart}>-</div>
              </div>
              <div className={styles.wrapper}>
                <div className={styles.div}>1</div>
              </div>
              <div className={styles.rectangleContainer}>
                <div className={styles.frameItem} />
                <div className={styles.div1}>+</div>
              </div>
            </div>
            <div className={styles.groupDiv}>
              <div className={styles.rectangleDiv} />
              <div className={styles.addToCart1}>add to cart</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

FrameComponent1.propTypes = {
  className: PropTypes.string,
  stpattysday1: PropTypes.string,
  stPattysDayCupcake: PropTypes.string,

  /** Style props */
  propWidth: PropTypes.any,
  propGap: PropTypes.any,
  propAlignSelf: PropTypes.any,
  propAlignSelf1: PropTypes.any,
  propWidth1: PropTypes.any,
  propHeight: PropTypes.any,
  propMixBlendMode: PropTypes.any,
  propGap1: PropTypes.any,
  propHeight1: PropTypes.any,
  propDisplay: PropTypes.any,
  propGap2: PropTypes.any,
};

export default FrameComponent1;
