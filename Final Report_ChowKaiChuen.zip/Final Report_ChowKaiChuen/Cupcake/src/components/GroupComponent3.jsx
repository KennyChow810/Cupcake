import { useCallback } from "react";
import FrameComponent from "./FrameComponent";
import { useNavigate } from "react-router-dom";
import InfoLinks from "./InfoLinks";
import PropTypes from "prop-types";
import styles from "./GroupComponent3.module.css";

const GroupComponent3 = ({ className = "" }) => {
  const navigate = useNavigate();

  const onCUPCAKESTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available");
  }, [navigate]);

  const onCorporateEventTextClick = useCallback(() => {
    navigate("/corporate-event");
  }, [navigate]);

  return (
    <header className={[styles.rectangleParent, className].join(" ")}>
      <div className={styles.frameChild} />
      <FrameComponent hOMEPadding="unset" />
      <div className={styles.cupcakesCorporateDetails}>
        <a className={styles.cupcakes} onClick={onCUPCAKESTextClick}>
          CUPCAKES
        </a>
      </div>
      <div className={styles.cupcakesCorporateDetails1}>
        <a
          className={styles.corporateEvent}
          onClick={onCorporateEventTextClick}
        >
          corporate event
        </a>
      </div>
      <div className={styles.customizationTitleWrapper}>
        <div className={styles.customizationTitle}>
          <a className={styles.customization}>Customization</a>
          <div className={styles.customizationTitleInner}>
            <div className={styles.frameItem} />
          </div>
        </div>
      </div>
      <InfoLinks />
    </header>
  );
};

GroupComponent3.propTypes = {
  className: PropTypes.string,
};

export default GroupComponent3;
