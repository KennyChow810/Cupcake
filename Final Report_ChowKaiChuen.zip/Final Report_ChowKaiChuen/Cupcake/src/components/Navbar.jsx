import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";
import styles from "./Navbar.module.css";

const Navbar = ({ className = "" }) => {
  const navigate = useNavigate();

  const onHOMETextClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  const onCUPCAKESTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available");
  }, [navigate]);

  const onCorporateEventTextClick = useCallback(() => {
    navigate("/corporate-event");
  }, [navigate]);

  const onCustomizationTextClick = useCallback(() => {
    navigate("/customization");
  }, [navigate]);

  const onCONTACTTextClick = useCallback(() => {
    navigate("/contact");
  }, [navigate]);

  const onFAQsTextClick = useCallback(() => {
    navigate("/faqs");
  }, [navigate]);

  const onCartIconClick = useCallback(() => {
    navigate("/cart");
  }, [navigate]);

  return (
    <section className={[styles.navbar, className].join(" ")}>
      <header className={styles.rectangleParent}>
        <div className={styles.frameChild} />
        <div className={styles.logo}>
          <img
            className={styles.torontoLogoIcon}
            loading="lazy"
            alt=""
            src="/toronto-logo@2x.png"
          />
        </div>
        <div className={styles.navLinks}>
          <div className={styles.homeParent}>
            <a className={styles.home} onClick={onHOMETextClick}>
              HOME
            </a>
            <a className={styles.cupcakes} onClick={onCUPCAKESTextClick}>
              CUPCAKES
            </a>
          </div>
        </div>
        <div className={styles.navLinks1}>
          <a
            className={styles.corporateEvent}
            onClick={onCorporateEventTextClick}
          >
            corporate event
          </a>
        </div>
        <div className={styles.navLinks2}>
          <a
            className={styles.corporateEvent}
            onClick={onCustomizationTextClick}
          >
            Customization
          </a>
        </div>
        <div className={styles.aboutContentWrapper}>
          <div className={styles.aboutContent}>
            <a className={styles.aboutUs}>ABOUT US</a>
            <div className={styles.aboutDivider}>
              <div className={styles.aboutDividerChild} />
            </div>
          </div>
        </div>
        <div className={styles.navLinks3}>
          <div className={styles.contactParent}>
            <a className={styles.contact} onClick={onCONTACTTextClick}>
              CONTACT
            </a>
            <a className={styles.faqs} onClick={onFAQsTextClick}>
              FAQs
            </a>
          </div>
        </div>
        <div className={styles.cart}>
          <img
            className={styles.cartIcon}
            loading="lazy"
            alt=""
            src="/cart@2x.png"
            onClick={onCartIconClick}
          />
        </div>
      </header>
    </section>
  );
};

Navbar.propTypes = {
  className: PropTypes.string,
};

export default Navbar;
