import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import GroupComponent from "./GroupComponent";
import ProductRowOne from "./ProductRowOne";
import ProductImagesTwo from "./ProductImagesTwo";
import ChocolateToffeeElements from "./ChocolateToffeeElements";
import CaramelTwoImage from "./CaramelTwoImage";
import ProductImages from "./ProductImages";
import FrameComponent1 from "./FrameComponent1";
import PropTypes from "prop-types";
import styles from "./Header2.module.css";

const Header2 = ({ className = "" }) => {
  const navigate = useNavigate();

  const onCUPCAKESTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available");
  }, [navigate]);

  const onHolidaysTextClick = useCallback(() => {
    navigate("/cupcakes-holidays-mother-day");
  }, [navigate]);

  const onEventTextClick = useCallback(() => {
    navigate("/cupcakes-event");
  }, [navigate]);

  const onOthersTextClick = useCallback(() => {
    navigate("/cupcakes-others");
  }, [navigate]);

  const onOneDozenAssortedClick = useCallback(() => {
    navigate("/-cupcakes-always-available-one-dozen-assorted-box");
  }, [navigate]);

  const onVanillaTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available-vanilla");
  }, [navigate]);

  const onRedVelvetTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available-red-velvet");
  }, [navigate]);

  return (
    <section className={[styles.header, className].join(" ")}>
      <GroupComponent onCUPCAKESTextClick={onCUPCAKESTextClick} />
      <div className={styles.categories}>
        <div className={styles.categoriesContent}>
          <div className={styles.categoryTitle}>
            <h1 className={styles.cupcakes}>CUPCAKES</h1>
          </div>
          <div className={styles.categoryOptions}>
            <div className={styles.optionsListParent}>
              <div className={styles.optionsList}>
                <div className={styles.optionItem}>
                  <div className={styles.availability}>
                    <h1
                      className={styles.alwaysAvailable}
                      onClick={onCUPCAKESTextClick}
                    >
                      always available
                    </h1>
                    <h1
                      className={styles.holidays}
                      onClick={onHolidaysTextClick}
                    >
                      holidays
                    </h1>
                  </div>
                  <div className={styles.event}>
                    <h1 className={styles.event1} onClick={onEventTextClick}>
                      event
                    </h1>
                  </div>
                  <h1 className={styles.others} onClick={onOthersTextClick}>
                    others
                  </h1>
                </div>
                <div className={styles.quantity}>
                  <div className={styles.each2150}>
                    $3.75 each | $21.50 half dozen | $41.5 dozen
                  </div>
                </div>
              </div>
              <div className={styles.productListing}>
                <div className={styles.products}>
                  <div className={styles.productRow}>
                    <div className={styles.categoriesParent}>
                      <b className={styles.categories1}>CATEGORIES</b>
                      <div className={styles.productCategory}>
                        <div
                          className={styles.oneDozenAssorted}
                          onClick={onOneDozenAssortedClick}
                        >{`One dozen assorted box `}</div>
                        <div className={styles.chocolateOption}>
                          <div className={styles.chocolate}>Chocolate</div>
                        </div>
                        <div className={styles.chocolateOption}>
                          <div
                            className={styles.vanilla}
                            onClick={onVanillaTextClick}
                          >
                            Vanilla
                          </div>
                        </div>
                        <div className={styles.chocolateOption}>
                          <div
                            className={styles.oneDozenAssorted}
                            onClick={onRedVelvetTextClick}
                          >
                            Red Velvet
                          </div>
                        </div>
                        <div
                          className={styles.all}
                          onClick={onCUPCAKESTextClick}
                        >
                          ALL
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className={styles.productCards}>
                    <ProductRowOne
                      propPadding="0px 0px 18px"
                      propGap="3px"
                      propAlignSelf="stretch"
                      propWidth="unset"
                      image19="/image-19@2x.png"
                      propWidth1="133.6px"
                      propFlex="unset"
                      propOverflow="unset"
                      vanillaChocolate="vanilla chocolate"
                      propAlignSelf1="stretch"
                      propWidth2="unset"
                      propWidth3="186.9px"
                      propAlignSelf2="unset"
                    />
                    <ProductRowOne
                      propPadding="0px 0px 10px"
                      propGap="2px"
                      propAlignSelf="unset"
                      propWidth="178px"
                      image19="/image-20@2x.png"
                      propWidth1="unset"
                      propFlex="1"
                      propOverflow="hidden"
                      vanillaChocolate="vanilla chocolate ganache"
                      propAlignSelf1="stretch"
                      propWidth2="unset"
                      propWidth3="186.9px"
                      propAlignSelf2="unset"
                    />
                    <ProductRowOne
                      propPadding="unset"
                      propGap="unset"
                      propAlignSelf="unset"
                      propWidth="unset"
                      image19="/image-28@2x.png"
                      propWidth1="146px"
                      propFlex="unset"
                      propOverflow="unset"
                      vanillaChocolate="chocolate hazelnut"
                      propAlignSelf1="stretch"
                      propWidth2="unset"
                      propWidth3="186.9px"
                      propAlignSelf2="unset"
                    />
                    <div className={styles.productCardsInner}>
                      <div className={styles.frameParent}>
                        <div className={styles.image41Wrapper}>
                          <img
                            className={styles.image41Icon}
                            loading="lazy"
                            alt=""
                            src="/image-41@2x.png"
                          />
                        </div>
                        <div className={styles.chocolateChocolateGanacheParent}>
                          <div className={styles.chocolateChocolateGanache}>
                            chocolate chocolate ganache
                          </div>
                          <div className={styles.frameGroup}>
                            <div className={styles.rectangleParent}>
                              <div className={styles.frameChild} />
                              <div className={styles.parent}>
                                <div className={styles.div}>1</div>
                                <div className={styles.rectangleGroup}>
                                  <div className={styles.frameItem} />
                                  <div className={styles.div1}>-</div>
                                </div>
                                <div className={styles.rectangleGroup}>
                                  <div className={styles.frameItem} />
                                  <div className={styles.div2}>+</div>
                                </div>
                                <div className={styles.rectangleDiv} />
                                <div className={styles.frameDiv}>
                                  <div
                                    className={
                                      styles.chocolateMochaAddDummyChild
                                    }
                                  />
                                  <div className={styles.chocolateMochaAdd}>
                                    -
                                  </div>
                                </div>
                                <div className={styles.wrapper}>
                                  <div className={styles.chocolatePeanutValue}>
                                    1
                                  </div>
                                </div>
                                <div className={styles.rectangleParent1}>
                                  <div
                                    className={
                                      styles.chocolateMochaAddDummyChild
                                    }
                                  />
                                  <div className={styles.div5}>+</div>
                                </div>
                              </div>
                            </div>
                            <div className={styles.groupDiv}>
                              <div className={styles.frameChild3} />
                              <div className={styles.addToCartParent}>
                                <div className={styles.addToCart}>
                                  add to cart
                                </div>
                                <div className={styles.frameChild3} />
                                <div className={styles.addToCart1}>
                                  add to cart
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className={styles.frameContainer}>
                    <ProductImagesTwo
                      propPadding="0px 0px 20px"
                      propGap="1px"
                      propWidth="158.9px"
                      propAlignSelf="unset"
                      image21="/image-21@2x.png"
                      propMixBlendMode="multiply"
                      chocolateCaramel="chocolate caramel"
                    />
                    <ChocolateToffeeElements
                      propGap="unset"
                      propPadding="0px 0px 10px"
                      propAlignSelf="stretch"
                      propFlex="unset"
                      propWidth="unset"
                      image27="/image-26@2x.png"
                      propFlex1="unset"
                      propOverflow="unset"
                      propWidth1="144.9px"
                      propWidth2="unset"
                      propAlignSelf1="stretch"
                      chocolateToffeeOreo="chocolate oreo"
                      propGap1="22.4px"
                    />
                    <ProductImagesTwo
                      propPadding="unset"
                      propGap="unset"
                      propWidth="unset"
                      propAlignSelf="stretch"
                      image21="/image-31@2x.png"
                      propMixBlendMode="unset"
                      chocolateCaramel="chocolate coconut"
                    />
                    <div className={styles.frameParent1}>
                      <div className={styles.image42Wrapper}>
                        <img
                          className={styles.image42Icon}
                          loading="lazy"
                          alt=""
                          src="/image-42@2x.png"
                        />
                      </div>
                      <div className={styles.frameParent2}>
                        <div className={styles.chocolateMochaWrapper}>
                          <div className={styles.chocolateMocha}>
                            chocolate mocha
                          </div>
                        </div>
                        <div className={styles.chocolateMochaPrice}>
                          <div className={styles.rectangleParent}>
                            <div className={styles.frameChild} />
                            <div className={styles.parent}>
                              <div className={styles.div}>1</div>
                              <div className={styles.rectangleGroup}>
                                <div className={styles.frameItem} />
                                <div className={styles.div7}>-</div>
                              </div>
                              <div className={styles.rectangleGroup}>
                                <div className={styles.frameItem} />
                                <div className={styles.div8}>+</div>
                              </div>
                              <div className={styles.rectangleDiv} />
                              <div className={styles.frameDiv}>
                                <div
                                  className={styles.chocolateMochaAddDummyChild}
                                />
                                <div className={styles.chocolateMochaAdd}>
                                  -
                                </div>
                              </div>
                              <div className={styles.wrapper}>
                                <div className={styles.chocolatePeanutValue}>
                                  1
                                </div>
                              </div>
                              <div className={styles.rectangleParent1}>
                                <div
                                  className={styles.chocolateMochaAddDummyChild}
                                />
                                <div className={styles.div5}>+</div>
                              </div>
                            </div>
                          </div>
                          <div className={styles.groupDiv}>
                            <div className={styles.frameChild3} />
                            <div className={styles.addToCartParent}>
                              <div className={styles.addToCart}>
                                add to cart
                              </div>
                              <div className={styles.frameChild3} />
                              <div className={styles.addToCart1}>
                                add to cart
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className={styles.productImagesParent}>
                    <div className={styles.productImages}>
                      <CaramelTwoImage
                        propAlignSelf="unset"
                        propPadding="unset"
                        propFlex="1"
                        image23="/image-23@2x.png"
                        propWidth="154.4px"
                      />
                    </div>
                    <div className={styles.productImage}>
                      <div className={styles.chocolatePeanutImage}>
                        <img
                          className={styles.image41Icon}
                          loading="lazy"
                          alt=""
                          src="/image-32@2x.png"
                        />
                      </div>
                      <div className={styles.chocolatePeanutTitle}>
                        <div className={styles.chocolatePeanutButter}>
                          chocolate peanut butter
                        </div>
                        <div className={styles.chocolatePeanutPrice}>
                          <div className={styles.chocolatePeanutActions}>
                            <div className={styles.rectangleParent}>
                              <div className={styles.frameChild} />
                              <div className={styles.container}>
                                <div className={styles.div}>1</div>
                                <div className={styles.rectangleGroup}>
                                  <div className={styles.frameItem} />
                                  <div className={styles.div1}>-</div>
                                </div>
                                <div className={styles.rectangleGroup}>
                                  <div className={styles.frameItem} />
                                  <div className={styles.div2}>+</div>
                                </div>
                                <div className={styles.rectangleDiv} />
                                <div className={styles.frameDiv}>
                                  <div
                                    className={
                                      styles.chocolateMochaAddDummyChild
                                    }
                                  />
                                  <div className={styles.chocolateMochaAdd}>
                                    -
                                  </div>
                                </div>
                                <div className={styles.wrapper}>
                                  <div className={styles.chocolatePeanutValue}>
                                    1
                                  </div>
                                </div>
                                <div className={styles.rectangleParent1}>
                                  <div
                                    className={
                                      styles.chocolateMochaAddDummyChild
                                    }
                                  />
                                  <div className={styles.div5}>+</div>
                                </div>
                              </div>
                            </div>
                            <div className={styles.rectangleParent9}>
                              <div className={styles.frameChild3} />
                              <div className={styles.addToCart1}>
                                add to cart
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <ProductImages
                      image29="/image-29@2x.png"
                      chocolateVanilla="chocolate vanilla"
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.productsTwo}>
              <div className={styles.productsTwoRow}>
                <div className={styles.productsTwoImages}>
                  <ChocolateToffeeElements
                    propGap="1px"
                    propPadding="unset"
                    propAlignSelf="unset"
                    propFlex="1"
                    propWidth="151.8px"
                    image27="/image-27@2x.png"
                    propFlex1="1"
                    propOverflow="hidden"
                    propWidth1="unset"
                    propWidth2="151.8px"
                    propAlignSelf1="unset"
                    chocolateToffeeOreo="chocolate toffee oreo"
                    propGap1="15.3px"
                  />
                </div>
                <ProductImages
                  propGap="10px"
                  propWidth="unset"
                  propAlignSelf="stretch"
                  image29="/image-35@2x.png"
                  propGap1="13px"
                  propWidth1="unset"
                  propAlignSelf1="stretch"
                  chocolateVanilla="chocolate chocolate"
                  propGap2="15.3px"
                />
                <FrameComponent1
                  propWidth="unset"
                  propGap="unset"
                  propAlignSelf="stretch"
                  propAlignSelf1="unset"
                  propWidth1="189.3px"
                  stpattysday1="/image-40@2x.png"
                  propHeight="148px"
                  propMixBlendMode="multiply"
                  propGap1="18.1px"
                  stPattysDayCupcake="chocolate vanilla choclate ganache"
                  propHeight1="13.9px"
                  propDisplay="inline-block"
                  propGap2="15.3px"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

Header2.propTypes = {
  className: PropTypes.string,
};

export default Header2;
