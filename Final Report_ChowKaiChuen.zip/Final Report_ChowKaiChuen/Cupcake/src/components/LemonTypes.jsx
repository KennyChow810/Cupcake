import { useMemo } from "react";
import PropTypes from "prop-types";
import styles from "./LemonTypes.module.css";

const LemonTypes = ({
  className = "",
  propPadding,
  propGap,
  propWidth,
  propAlignSelf,
  image24,
  propMixBlendMode,
  propGap1,
  propWidth1,
  propAlignSelf1,
  lemonVanilla,
}) => {
  const lemonTypesStyle = useMemo(() => {
    return {
      padding: propPadding,
      gap: propGap,
    };
  }, [propPadding, propGap]);

  const lemonQuantityStyle = useMemo(() => {
    return {
      width: propWidth,
      alignSelf: propAlignSelf,
    };
  }, [propWidth, propAlignSelf]);

  const image24IconStyle = useMemo(() => {
    return {
      mixBlendMode: propMixBlendMode,
    };
  }, [propMixBlendMode]);

  const sundaeImageStyle = useMemo(() => {
    return {
      gap: propGap1,
    };
  }, [propGap1]);

  const sundaeNameStyle = useMemo(() => {
    return {
      width: propWidth1,
      alignSelf: propAlignSelf1,
    };
  }, [propWidth1, propAlignSelf1]);

  return (
    <div
      className={[styles.lemonTypes, className].join(" ")}
      style={lemonTypesStyle}
    >
      <div className={styles.lemonQuantity} style={lemonQuantityStyle}>
        <img
          className={styles.image24Icon}
          loading="lazy"
          alt=""
          src={image24}
          style={image24IconStyle}
        />
      </div>
      <div className={styles.sundaeImage} style={sundaeImageStyle}>
        <div className={styles.sundaeName} style={sundaeNameStyle}>
          <div className={styles.lemonVanilla}>{lemonVanilla}</div>
        </div>
        <div className={styles.sundaeType}>
          <div className={styles.rectangleParent}>
            <div className={styles.frameChild} />
            <div className={styles.parent}>
              <div className={styles.div}>1</div>
              <div className={styles.rectangleGroup}>
                <div className={styles.frameItem} />
                <div className={styles.div1}>-</div>
              </div>
              <div className={styles.rectangleGroup}>
                <div className={styles.frameItem} />
                <div className={styles.div2}>+</div>
              </div>
              <div className={styles.rectangleDiv} />
              <div className={styles.sundaePrices}>
                <div className={styles.sundaePricesChild} />
                <div className={styles.mochaImage}>-</div>
              </div>
              <div className={styles.mochaName}>
                <div className={styles.mochaFlavor}>1</div>
              </div>
              <div className={styles.mochaType}>
                <div className={styles.sundaePricesChild} />
                <div className={styles.mochaTypes}>+</div>
              </div>
            </div>
          </div>
          <div className={styles.groupDiv}>
            <div className={styles.frameChild1} />
            <div className={styles.addToCart}>add to cart</div>
          </div>
        </div>
      </div>
    </div>
  );
};

LemonTypes.propTypes = {
  className: PropTypes.string,
  image24: PropTypes.string,
  lemonVanilla: PropTypes.string,

  /** Style props */
  propPadding: PropTypes.any,
  propGap: PropTypes.any,
  propWidth: PropTypes.any,
  propAlignSelf: PropTypes.any,
  propMixBlendMode: PropTypes.any,
  propGap1: PropTypes.any,
  propWidth1: PropTypes.any,
  propAlignSelf1: PropTypes.any,
};

export default LemonTypes;
