import { useMemo } from "react";
import PropTypes from "prop-types";
import styles from "./CaramelTwoImage.module.css";

const CaramelTwoImage = ({
  className = "",
  propAlignSelf,
  propPadding,
  propFlex,
  image23,
  propWidth,
}) => {
  const caramelTwoImageStyle = useMemo(() => {
    return {
      alignSelf: propAlignSelf,
      padding: propPadding,
      flex: propFlex,
    };
  }, [propAlignSelf, propPadding, propFlex]);

  const caramelTwoTypeStyle = useMemo(() => {
    return {
      width: propWidth,
    };
  }, [propWidth]);

  return (
    <div
      className={[styles.caramelTwoImage, className].join(" ")}
      style={caramelTwoImageStyle}
    >
      <img className={styles.image23Icon} loading="lazy" alt="" src={image23} />
      <div className={styles.caramelTwoName}>
        <div className={styles.caramelTwoFlavor}>
          <div className={styles.caramelTwoType} style={caramelTwoTypeStyle}>
            <div className={styles.chocolateCarmelIi}>chocolate carmel II</div>
          </div>
          <div className={styles.caramelTwoQuantity}>
            <div className={styles.rectangleParent}>
              <div className={styles.frameChild} />
              <div className={styles.parent}>
                <div className={styles.div}>1</div>
                <div className={styles.rectangleGroup}>
                  <div className={styles.frameItem} />
                  <div className={styles.div1}>-</div>
                </div>
                <div className={styles.rectangleGroup}>
                  <div className={styles.frameItem} />
                  <div className={styles.div2}>+</div>
                </div>
                <div className={styles.rectangleDiv} />
                <div className={styles.caramelTwoValue}>
                  <div className={styles.caramelTwoValueChild} />
                  <div className={styles.caramelTwoAdd}>-</div>
                </div>
                <div className={styles.caramelTwoButton}>
                  <div className={styles.caramelTwoCart}>1</div>
                </div>
                <div className={styles.caramelTwoValue1}>
                  <div className={styles.caramelTwoValueChild} />
                  <div className={styles.div3}>+</div>
                </div>
              </div>
            </div>
            <div className={styles.groupDiv}>
              <div className={styles.frameChild1} />
              <div className={styles.addToCart}>add to cart</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

CaramelTwoImage.propTypes = {
  className: PropTypes.string,
  image23: PropTypes.string,

  /** Style props */
  propAlignSelf: PropTypes.any,
  propPadding: PropTypes.any,
  propFlex: PropTypes.any,
  propWidth: PropTypes.any,
};

export default CaramelTwoImage;
