import PropTypes from "prop-types";
import styles from "./LastNameContact.module.css";

const LastNameContact = ({ className = "" }) => {
  return (
    <div className={[styles.lastNameContact, className].join(" ")}>
      <div className={styles.lastNameInput}>
        <div className={styles.lastName}>Last Name</div>
      </div>
      <div className={styles.lastNameBackground}>
      <input type="text" className={styles.lastNameInputBackground} />
      </div>
      <div className={styles.contactNo}>Contact no.</div>
      <input type="text" className={styles.contactBackground} />
    </div>
  );
};

LastNameContact.propTypes = {
  className: PropTypes.string,
};

export default LastNameContact;
