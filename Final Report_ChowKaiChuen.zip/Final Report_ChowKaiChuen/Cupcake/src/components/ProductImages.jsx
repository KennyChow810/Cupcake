import { useMemo } from "react";
import PropTypes from "prop-types";
import styles from "./ProductImages.module.css";

const ProductImages = ({
  className = "",
  propGap,
  propWidth,
  propAlignSelf,
  image29,
  propGap1,
  propWidth1,
  propAlignSelf1,
  chocolateVanilla,
  propGap2,
}) => {
  const frameDiv2Style = useMemo(() => {
    return {
      gap: propGap,
    };
  }, [propGap]);

  const frameDiv3Style = useMemo(() => {
    return {
      width: propWidth,
      alignSelf: propAlignSelf,
    };
  }, [propWidth, propAlignSelf]);

  const frameDiv4Style = useMemo(() => {
    return {
      gap: propGap1,
    };
  }, [propGap1]);

  const frameDiv5Style = useMemo(() => {
    return {
      width: propWidth1,
      alignSelf: propAlignSelf1,
    };
  }, [propWidth1, propAlignSelf1]);

  const chocolateCaramelPriceStyle = useMemo(() => {
    return {
      gap: propGap2,
    };
  }, [propGap2]);

  return (
    <div className={[styles.productImages, className].join(" ")}>
      <div className={styles.frameParent} style={frameDiv2Style}>
        <div className={styles.image29Wrapper} style={frameDiv3Style}>
          <img
            className={styles.image29Icon}
            loading="lazy"
            alt=""
            src={image29}
          />
        </div>
        <div className={styles.frameGroup} style={frameDiv4Style}>
          <div
            className={styles.chocolateVanillaWrapper}
            style={frameDiv5Style}
          >
            <div className={styles.chocolateVanilla}>{chocolateVanilla}</div>
          </div>
          <div
            className={styles.chocolateCaramelPrice}
            style={chocolateCaramelPriceStyle}
          >
            <div className={styles.rectangleParent}>
              <div className={styles.frameChild} />
              <div className={styles.chocolateCaramelAdd}>
                <div className={styles.chocolateCaramelAddChild} />
                <div className={styles.chocolateCaramelAdd1}>-</div>
              </div>
              <div className={styles.chocolateCaramelAddPrice}>
                <div className={styles.chocolateCaramelAdd2}>1</div>
              </div>
              <div className={styles.chocolateCaramelDummy}>
                <div className={styles.chocolateCaramelAddChild} />
                <div className={styles.chocolateCaramelValue}>+</div>
              </div>
            </div>
            <div className={styles.rectangleGroup}>
              <div className={styles.frameItem} />
              <div className={styles.addToCart}>add to cart</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

ProductImages.propTypes = {
  className: PropTypes.string,
  image29: PropTypes.string,
  chocolateVanilla: PropTypes.string,

  /** Style props */
  propGap: PropTypes.any,
  propWidth: PropTypes.any,
  propAlignSelf: PropTypes.any,
  propGap1: PropTypes.any,
  propWidth1: PropTypes.any,
  propAlignSelf1: PropTypes.any,
  propGap2: PropTypes.any,
};

export default ProductImages;
