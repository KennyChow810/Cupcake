import PropTypes from "prop-types";
import styles from "./FaqsContent.module.css";

const FaqsContent = ({ className = "" }) => {
  return (
    <div className={[styles.faqsContent, className].join(" ")}>
      <div className={styles.questions}>
        <div className={styles.frequentlyAskedQuestions}>
          Frequently Asked Questions
        </div>
        <div className={styles.questionsList}>
          <div className={styles.ordering}>
            <div className={styles.orderingHowMuchContainer}>
              <p className={styles.deliverypickUpsending}>ORDERING</p>
              <p className={styles.howMuchTime}>{`
How much time for a custom order?`}</p>
              <p className={styles.howMuchTime}>&nbsp;</p>
              <p className={styles.howMuchTime}>
                What is the smallest order I can make?
              </p>
              <p className={styles.howMuchTime}>&nbsp;</p>
              <p className={styles.howMuchTime}>
                What are my options for payment?
              </p>
              <p className={styles.howMuchTime}>&nbsp;</p>
              <p className={styles.howMuchTime}>When and how do I pay?</p>
            </div>
            <div className={styles.ingredients}>
              <div className={styles.ingredientsDoYouContainer}>
                <p className={styles.deliverypickUpsending}>{`INGREDIENTS
`}</p>
                <p className={styles.howMuchTime}>
                  Do you have gluten free cupcakes?
                </p>
                <p className={styles.howMuchTime}>&nbsp;</p>
                <p className={styles.howMuchTime}>What colours do you have?</p>
                <p className={styles.howMuchTime}>&nbsp;</p>
                <p className={styles.howMuchTime}>
                  Do you offer special icing colours?
                </p>
                <p className={styles.howMuchTime}>&nbsp;</p>
                <p className={styles.howMuchTime}>
                  Are Toronto Cupcake products nut free?
                </p>
              </div>
            </div>
            <div className={styles.delivery}>
              <div className={styles.deliverypickUpsendingDoesContainer}>
                <p className={styles.deliverypickUpsending}>
                  DELIVERY/PICK UP/SENDING
                </p>
                <p className={styles.howMuchTime}>{`
Does Toronto Cupcake deliver?`}</p>
                <p className={styles.howMuchTime}>&nbsp;</p>
                <p className={styles.howMuchTime}>
                  What's the earliest time I can get delivery?
                </p>
                <p className={styles.howMuchTime}>&nbsp;</p>
                <p className={styles.howMuchTime}>Can I pickup my cupcakes?</p>
                <p className={styles.howMuchTime}>&nbsp;</p>
                <p className={styles.howMuchTime}>
                  What if the person isn't home?
                </p>
              </div>
              <div className={styles.otherHowDoContainer}>
                <p className={styles.howMuchTime}>
                  <span>
                    <span>OTHER</span>
                  </span>
                </p>
                <p className={styles.howDoIStoreMyCupcakes}>
                  <span>
                    <span>{`
How do I store my cupcakes?`}</span>
                  </span>
                </p>
                <p className={styles.howMuchTime}>
                  <span>
                    <span>&nbsp;</span>
                  </span>
                </p>
                <p className={styles.howMuchTime}>
                  <span>
                    <span>Are you able to personalise cupcakes?</span>
                  </span>
                </p>
                <p className={styles.howMuchTime}>
                  <span>
                    <span>&nbsp;</span>
                  </span>
                </p>
                <p className={styles.howMuchTime}>
                  <span>
                    <span>Do I need to order my cupcakes in advance?</span>
                  </span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

FaqsContent.propTypes = {
  className: PropTypes.string,
};

export default FaqsContent;
