import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import GroupComponent from "./GroupComponent";
import CoconutImage from "./CoconutImage";
import ProductRowOne from "./ProductRowOne";
import PropTypes from "prop-types";
import styles from "./FrameComponent7.module.css";

const FrameComponent7 = ({ className = "" }) => {
  const navigate = useNavigate();

  const onCUPCAKESTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available");
  }, [navigate]);

  const onHolidaysTextClick = useCallback(() => {
    navigate("/cupcakes-holidays-mother-day");
  }, [navigate]);

  const onEventTextClick = useCallback(() => {
    navigate("/cupcakes-event");
  }, [navigate]);

  const onOthersTextClick = useCallback(() => {
    navigate("/cupcakes-others");
  }, [navigate]);

  const onOneDozenAssortedClick = useCallback(() => {
    navigate("/-cupcakes-always-available-one-dozen-assorted-box");
  }, [navigate]);

  const onChocolateTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available-choclate");
  }, [navigate]);

  const onVanillaTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available-vanilla");
  }, [navigate]);

  return (
    <section className={[styles.frameParent, className].join(" ")}>
      <GroupComponent onCUPCAKESTextClick={onCUPCAKESTextClick} />
      <div className={styles.frameWrapper}>
        <div className={styles.frameGroup}>
          <div className={styles.frameContainer}>
            <div className={styles.cupcakesWrapper}>
              <h1 className={styles.cupcakes}>CUPCAKES</h1>
            </div>
            <div className={styles.frameDiv}>
              <div className={styles.frameParent1}>
                <div className={styles.alwaysAvailableParent}>
                  <h1
                    className={styles.alwaysAvailable}
                    onClick={onCUPCAKESTextClick}
                  >
                    always available
                  </h1>
                  <h1 className={styles.holidays} onClick={onHolidaysTextClick}>
                    holidays
                  </h1>
                </div>
                <div className={styles.event}>
                  <h1 className={styles.event1} onClick={onEventTextClick}>
                    event
                  </h1>
                </div>
                <h1 className={styles.others} onClick={onOthersTextClick}>
                  others
                </h1>
              </div>
              <div className={styles.quantity}>
                <div className={styles.each2150}>
                  $3.75 each | $21.50 half dozen | $41.5 dozen
                </div>
              </div>
            </div>
          </div>
          <div className={styles.frameWrapper1}>
            <div className={styles.frameParent2}>
              <div className={styles.categoryListWrapper}>
                <div className={styles.categoryList}>
                  <b className={styles.categories}>CATEGORIES</b>
                  <div className={styles.categoryItems}>
                    <div
                      className={styles.oneDozenAssorted}
                      onClick={onOneDozenAssortedClick}
                    >{`One dozen assorted box `}</div>
                    <div className={styles.assortedBox}>
                      <div
                        className={styles.oneDozenAssorted}
                        onClick={onChocolateTextClick}
                      >
                        Chocolate
                      </div>
                    </div>
                    <div className={styles.assortedBox}>
                      <div
                        className={styles.vanilla}
                        onClick={onVanillaTextClick}
                      >
                        Vanilla
                      </div>
                    </div>
                    <div className={styles.assortedBox}>
                      <div className={styles.redVelvet}>Red Velvet</div>
                    </div>
                    <div className={styles.all} onClick={onCUPCAKESTextClick}>
                      ALL
                    </div>
                  </div>
                </div>
              </div>
              <CoconutImage
                propAlignSelf="unset"
                propWidth="192.2px"
                image34="/image-33@2x.png"
                propMixBlendMode="unset"
                propAlignSelf1="unset"
                propWidth1="141.6px"
                vanillaCoconut="red velvet"
                propGap="20.3px"
              />
              <div className={styles.frameWrapper2}>
                <ProductRowOne
                  propPadding="unset"
                  propGap="5px"
                  propAlignSelf="stretch"
                  propWidth="unset"
                  image19="/image-37@2x.png"
                  propWidth1="unset"
                  propFlex="1"
                  propOverflow="hidden"
                  vanillaChocolate="red velvet fudge"
                  propAlignSelf1="unset"
                  propWidth2="165.7px"
                  propWidth3="unset"
                  propAlignSelf2="stretch"
                />
              </div>
              <div className={styles.frameWrapper3}>
                <div className={styles.image39Parent}>
                  <img
                    className={styles.image39Icon}
                    loading="lazy"
                    alt=""
                    src="/image-39@2x.png"
                  />
                  <div className={styles.frameWrapper4}>
                    <div className={styles.frameParent3}>
                      <div className={styles.redVelvetRaspberryWrapper}>
                        <div className={styles.redVelvetRaspberryContainer}>
                          <p className={styles.redVelvetRaspberry}>
                            red velvet raspberry
                          </p>
                        </div>
                      </div>
                      <div className={styles.frameParent4}>
                        <div className={styles.rectangleParent}>
                          <div className={styles.frameChild} />
                          <div className={styles.parent}>
                            <div className={styles.div}>1</div>
                            <div className={styles.rectangleGroup}>
                              <div className={styles.frameItem} />
                              <div className={styles.div1}>-</div>
                            </div>
                            <div className={styles.rectangleGroup}>
                              <div className={styles.frameItem} />
                              <div className={styles.div2}>+</div>
                            </div>
                            <div className={styles.rectangleDiv} />
                            <div className={styles.raspberryAddToCartSeparato}>
                              <div
                                className={
                                  styles.raspberryAddToCartSeparatoChild
                                }
                              />
                              <div className={styles.raspberrySeparator}>-</div>
                            </div>
                            <div className={styles.raspberryAddToCartSpacer}>
                              <div className={styles.raspberrySpacer}>1</div>
                            </div>
                            <div className={styles.raspberryAddToCartSeparato1}>
                              <div
                                className={
                                  styles.raspberryAddToCartSeparatoChild
                                }
                              />
                              <div className={styles.div3}>+</div>
                            </div>
                          </div>
                        </div>
                        <div className={styles.groupDiv}>
                          <div className={styles.frameChild1} />
                          <div className={styles.addToCart}>add to cart</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

FrameComponent7.propTypes = {
  className: PropTypes.string,
};

export default FrameComponent7;
