import { useMemo } from "react";
import PropTypes from "prop-types";
import styles from "./ProductVariations.module.css";

const ProductVariations = ({ className = "", propGap, jazz1, propHeight }) => {
  const productVariationsStyle = useMemo(() => {
    return {
      gap: propGap,
    };
  }, [propGap]);

  const jazz1IconStyle = useMemo(() => {
    return {
      height: propHeight,
    };
  }, [propHeight]);

  return (
    <div
      className={[styles.productVariations, className].join(" ")}
      style={productVariationsStyle}
    >
      <div className={styles.jazz1Wrapper}>
        <img
          className={styles.jazz1Icon}
          loading="lazy"
          alt=""
          src={jazz1}
          style={jazz1IconStyle}
        />
      </div>
      <div className={styles.frameParent}>
        <div className={styles.rectangleParent}>
          <div className={styles.frameChild} />
          <div className={styles.rectangleGroup}>
            <div className={styles.frameItem} />
            <div className={styles.div}>-</div>
          </div>
          <div className={styles.wrapper}>
            <div className={styles.div1}>1</div>
          </div>
          <div className={styles.rectangleContainer}>
            <div className={styles.frameItem} />
            <div className={styles.div2}>+</div>
          </div>
        </div>
        <div className={styles.groupDiv}>
          <div className={styles.rectangleDiv} />
          <div className={styles.addToCart}>add to cart</div>
        </div>
      </div>
    </div>
  );
};

ProductVariations.propTypes = {
  className: PropTypes.string,
  jazz1: PropTypes.string,

  /** Style props */
  propGap: PropTypes.any,
  propHeight: PropTypes.any,
};

export default ProductVariations;
