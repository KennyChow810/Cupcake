import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import GroupComponent from "./GroupComponent";
import ProductRowOne from "./ProductRowOne";
import FrameComponent1 from "./FrameComponent1";
import ProductImages from "./ProductImages";
import LemonTypes from "./LemonTypes";
import PropTypes from "prop-types";
import styles from "./Page.module.css";

const Page = ({ className = "" }) => {
  const navigate = useNavigate();

  const onCUPCAKESTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available");
  }, [navigate]);

  const onHolidaysTextClick = useCallback(() => {
    navigate("/cupcakes-holidays-mother-day");
  }, [navigate]);

  const onEventTextClick = useCallback(() => {
    navigate("/cupcakes-event");
  }, [navigate]);

  const onOthersTextClick = useCallback(() => {
    navigate("/cupcakes-others");
  }, [navigate]);

  const onOneDozenAssortedClick = useCallback(() => {
    navigate("/-cupcakes-always-available-one-dozen-assorted-box");
  }, [navigate]);

  const onChocolateTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available-choclate");
  }, [navigate]);

  const onRedVelvetTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available-red-velvet");
  }, [navigate]);

  return (
    <section className={[styles.page, className].join(" ")}>
      <GroupComponent onCUPCAKESTextClick={onCUPCAKESTextClick} />
      <div className={styles.cupcakeCategories}>
        <div className={styles.categoryHeader}>
          <div className={styles.categoryTitle}>
            <h1 className={styles.cupcakes}>CUPCAKES</h1>
          </div>
          <div className={styles.categoryFilters}>
            <div className={styles.filterOptions}>
              <div className={styles.filterTypes}>
                <div className={styles.availabilityFilterParent}>
                  <div className={styles.availabilityFilter}>
                    <h1
                      className={styles.alwaysAvailable}
                      onClick={onCUPCAKESTextClick}
                    >
                      always available
                    </h1>
                    <h1
                      className={styles.holidays}
                      onClick={onHolidaysTextClick}
                    >
                      holidays
                    </h1>
                  </div>
                  <div className={styles.eventFilter}>
                    <h1 className={styles.event} onClick={onEventTextClick}>
                      event
                    </h1>
                  </div>
                  <h1 className={styles.others} onClick={onOthersTextClick}>
                    others
                  </h1>
                </div>
                <div className={styles.quantity}>
                  <div className={styles.each2150}>
                    $3.75 each | $21.50 half dozen | $41.5 dozen
                  </div>
                </div>
              </div>
              <div className={styles.categoryListing}>
                <div className={styles.categoryItems}>
                  <div className={styles.itemCards}>
                    <div className={styles.productCard}>
                      <b className={styles.categories}>CATEGORIES</b>
                      <div className={styles.cardDetails}>
                        <div
                          className={styles.oneDozenAssorted}
                          onClick={onOneDozenAssortedClick}
                        >{`One dozen assorted box `}</div>
                        <div className={styles.chocolateOption}>
                          <div
                            className={styles.oneDozenAssorted}
                            onClick={onChocolateTextClick}
                          >
                            Chocolate
                          </div>
                        </div>
                        <div className={styles.flavorOptions}>
                          <div className={styles.chocolateOption}>
                            <div className={styles.vanilla}>Vanilla</div>
                          </div>
                          <div className={styles.flavorSelection1}>
                            <div
                              className={styles.oneDozenAssorted}
                              onClick={onRedVelvetTextClick}
                            >
                              Red Velvet
                            </div>
                          </div>
                          <div
                            className={styles.all}
                            onClick={onCUPCAKESTextClick}
                          >
                            ALL
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className={styles.productImage}>
                    <ProductRowOne
                      propPadding="unset"
                      propGap="3px"
                      propAlignSelf="stretch"
                      propWidth="unset"
                      image19="/image-19@2x.png"
                      propWidth1="133.6px"
                      propFlex="unset"
                      propOverflow="unset"
                      vanillaChocolate="vanilla chocolate"
                      propAlignSelf1="stretch"
                      propWidth2="unset"
                      propWidth3="186.9px"
                      propAlignSelf2="unset"
                    />
                    <div className={styles.productImage1}>
                      <div className={styles.imageContainer}>
                        <div className={styles.imageBox}>
                          <img
                            className={styles.image34Icon}
                            loading="lazy"
                            alt=""
                            src="/image-34@2x.png"
                          />
                        </div>
                        <div className={styles.vanillaCoconut}>
                          vanilla coconut
                        </div>
                        <div className={styles.addToCartButton}>
                          <div className={styles.frameParent}>
                            <div className={styles.rectangleParent}>
                              <div className={styles.frameChild} />
                              <div className={styles.separator}>
                                <div className={styles.separatorChild} />
                                <div className={styles.delimiter}>-</div>
                              </div>
                              <div className={styles.spacer}>
                                <div className={styles.empty}>1</div>
                              </div>
                              <div className={styles.separator1}>
                                <div className={styles.separatorChild} />
                                <div className={styles.div}>+</div>
                              </div>
                            </div>
                            <div className={styles.rectangleGroup}>
                              <div className={styles.frameItem} />
                              <div className={styles.addToCart}>
                                add to cart
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className={styles.productImage2}>
                    <FrameComponent1
                      propWidth="unset"
                      propGap="2px"
                      propAlignSelf="stretch"
                      propAlignSelf1="unset"
                      propWidth1="178px"
                      stpattysday1="/image-20@2x.png"
                      propHeight="148px"
                      propMixBlendMode="multiply"
                      propGap1="20.1px"
                      stPattysDayCupcake="vanilla chocolate ganache"
                      propHeight1="13.9px"
                      propDisplay="inline-block"
                      propGap2="22.4px"
                    />
                    <ProductImages
                      propGap="1px"
                      propWidth="139.2px"
                      propAlignSelf="unset"
                      image29="/image-29@2x.png"
                      propGap1="17px"
                      propWidth1="134.1px"
                      propAlignSelf1="unset"
                      chocolateVanilla="chocolate vanilla"
                      propGap2="22.4px"
                    />
                  </div>
                  <div className={styles.vanillaTrio}>
                    <LemonTypes
                      propPadding="unset"
                      propGap="unset"
                      propWidth="158.4px"
                      propAlignSelf="unset"
                      image24="/image-22@2x.png"
                      propMixBlendMode="unset"
                      propGap1="21.2px"
                      propWidth1="unset"
                      propAlignSelf1="stretch"
                      lemonVanilla="vanilla caramel"
                    />
                    <LemonTypes
                      propPadding="unset"
                      propGap="2px"
                      propWidth="unset"
                      propAlignSelf="stretch"
                      image24="/image-30@2x.png"
                      propMixBlendMode="unset"
                      propGap1="16px"
                      propWidth1="unset"
                      propAlignSelf1="stretch"
                      lemonVanilla="vanilla vanilla"
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.categoryFiltersInner}>
              <div className={styles.frameGroup}>
                <div className={styles.lemonVanillaImagesWrapper}>
                  <div className={styles.lemonVanillaImages}>
                    <div className={styles.image27} />
                    <img
                      className={styles.image24Icon}
                      loading="lazy"
                      alt=""
                      src="/image-24@2x.png"
                    />
                  </div>
                </div>
                <div className={styles.lemonVanillaProduct}>
                  <div className={styles.lemonVanillaName}>
                    <div className={styles.lemonVanilla}>lemon vanilla</div>
                  </div>
                  <div className={styles.lemonVanillaButton}>
                    <div className={styles.rectangleParent}>
                      <div className={styles.frameChild} />
                      <div className={styles.separator}>
                        <div className={styles.separatorChild} />
                        <div className={styles.delimiter}>-</div>
                      </div>
                      <div className={styles.spacer}>
                        <div className={styles.empty}>1</div>
                      </div>
                      <div className={styles.separator1}>
                        <div className={styles.separatorChild} />
                        <div className={styles.div}>+</div>
                      </div>
                    </div>
                    <div className={styles.rectangleGroup}>
                      <div className={styles.frameItem} />
                      <div className={styles.addToCart}>add to cart</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

Page.propTypes = {
  className: PropTypes.string,
};

export default Page;
