import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";
import styles from "./GroupComponent4.module.css";

const GroupComponent4 = ({ className = "" }) => {
  const navigate = useNavigate();

  const onHOMETextClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  const onCUPCAKESTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available");
  }, [navigate]);

  const onCorporateEventTextClick = useCallback(() => {
    navigate("/corporate-event");
  }, [navigate]);

  const onCustomizationTextClick = useCallback(() => {
    navigate("/customization");
  }, [navigate]);

  const onABOUTUSTextClick = useCallback(() => {
    navigate("/about-us");
  }, [navigate]);

  const onFAQsTextClick = useCallback(() => {
    navigate("/faqs");
  }, [navigate]);

  const onCartIconClick = useCallback(() => {
    navigate("/cart");
  }, [navigate]);

  return (
    <header className={[styles.rectangleParent, className].join(" ")}>
      <div className={styles.frameChild} />
      <div className={styles.logo}>
        <img
          className={styles.torontoLogoIcon}
          loading="lazy"
          alt=""
          src="/toronto-logo@2x.png"
        />
      </div>
      <nav className={styles.homeCupcakesCorporate}>
        <nav className={styles.homeCupcakesEvent}>
          <a className={styles.home} onClick={onHOMETextClick}>
            HOME
          </a>
          <a className={styles.cupcakes} onClick={onCUPCAKESTextClick}>
            CUPCAKES
          </a>
          <a
            className={styles.corporateEvent}
            onClick={onCorporateEventTextClick}
          >
            corporate event
          </a>
        </nav>
      </nav>
      <div className={styles.customizationItems}>
        <a className={styles.corporateEvent} onClick={onCustomizationTextClick}>
          Customization
        </a>
      </div>
      <div className={styles.customizationItems1}>
        <a className={styles.aboutUs} onClick={onABOUTUSTextClick}>
          ABOUT US
        </a>
      </div>
      <div className={styles.contactDetailsWrapper}>
        <div className={styles.contactDetails}>
          <a className={styles.contact}>CONTACT</a>
          <div className={styles.contactDetailsInner}>
            <div className={styles.frameItem} />
          </div>
        </div>
      </div>
      <div className={styles.customizationItems2}>
        <a className={styles.faqs} onClick={onFAQsTextClick}>
          FAQs
        </a>
      </div>
      <div className={styles.cart}>
        <img
          className={styles.cartIcon}
          loading="lazy"
          alt=""
          src="/cart@2x.png"
          onClick={onCartIconClick}
        />
      </div>
    </header>
  );
};

GroupComponent4.propTypes = {
  className: PropTypes.string,
};

export default GroupComponent4;
