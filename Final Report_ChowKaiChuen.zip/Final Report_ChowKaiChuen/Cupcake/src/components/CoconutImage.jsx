import { useMemo } from "react";
import PropTypes from "prop-types";
import styles from "./CoconutImage.module.css";

const CoconutImage = ({
  className = "",
  propAlignSelf,
  propWidth,
  image34,
  propMixBlendMode,
  propAlignSelf1,
  propWidth1,
  vanillaCoconut,
  propGap,
}) => {
  const coconutImageStyle = useMemo(() => {
    return {
      alignSelf: propAlignSelf,
      width: propWidth,
    };
  }, [propAlignSelf, propWidth]);

  const image34IconStyle = useMemo(() => {
    return {
      mixBlendMode: propMixBlendMode,
    };
  }, [propMixBlendMode]);

  const coconutFlavorStyle = useMemo(() => {
    return {
      alignSelf: propAlignSelf1,
      width: propWidth1,
    };
  }, [propAlignSelf1, propWidth1]);

  const coconutOptionsStyle = useMemo(() => {
    return {
      gap: propGap,
    };
  }, [propGap]);

  return (
    <div
      className={[styles.coconutImage, className].join(" ")}
      style={coconutImageStyle}
    >
      <div className={styles.coconutName}>
        <img
          className={styles.image34Icon}
          loading="lazy"
          alt=""
          src={image34}
          style={image34IconStyle}
        />
      </div>
      <div className={styles.coconutFlavor} style={coconutFlavorStyle}>
        <div className={styles.vanillaCoconut}>{vanillaCoconut}</div>
      </div>
      <div className={styles.coconutOptions} style={coconutOptionsStyle}>
        <div className={styles.rectangleParent}>
          <div className={styles.frameChild} />
          <div className={styles.coconutPrice}>
            <div className={styles.coconutPriceChild} />
            <div className={styles.coconutIncrement}>-</div>
          </div>
          <div className={styles.coconutValue}>
            <div className={styles.coconutAdd}>1</div>
          </div>
          <div className={styles.coconutPrice1}>
            <div className={styles.coconutPriceChild} />
            <div className={styles.div}>+</div>
          </div>
        </div>
        <div className={styles.rectangleGroup}>
          <div className={styles.frameItem} />
          <div className={styles.addToCart}>add to cart</div>
        </div>
      </div>
    </div>
  );
};

CoconutImage.propTypes = {
  className: PropTypes.string,
  image34: PropTypes.string,
  vanillaCoconut: PropTypes.string,

  /** Style props */
  propAlignSelf: PropTypes.any,
  propWidth: PropTypes.any,
  propMixBlendMode: PropTypes.any,
  propAlignSelf1: PropTypes.any,
  propWidth1: PropTypes.any,
  propGap: PropTypes.any,
};

export default CoconutImage;
