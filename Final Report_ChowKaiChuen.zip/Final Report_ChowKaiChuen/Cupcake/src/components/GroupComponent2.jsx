import { useCallback } from "react";
import FrameComponent from "./FrameComponent";
import { useNavigate } from "react-router-dom";
import InfoLinks from "./InfoLinks";
import PropTypes from "prop-types";
import styles from "./GroupComponent2.module.css";

const GroupComponent2 = ({ className = "" }) => {
  const navigate = useNavigate();

  const onCUPCAKESTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available");
  }, [navigate]);

  const onCustomizationTextClick = useCallback(() => {
    navigate("/customization");
  }, [navigate]);

  return (
    <header className={[styles.rectangleParent, className].join(" ")}>
      <div className={styles.frameChild} />
      <FrameComponent />
      <div className={styles.cupcakesCustomizationItems}>
        <a className={styles.cupcakes} onClick={onCUPCAKESTextClick}>
          CUPCAKES
        </a>
      </div>
      <div className={styles.corporateEventHeading}>
        <div className={styles.corporateEventTitle}>
          <a className={styles.corporateEvent}>corporate event</a>
          <div className={styles.corporateEventTitleInner}>
            <div className={styles.frameItem} />
          </div>
        </div>
      </div>
      <div className={styles.cupcakesCustomizationItems1}>
        <a className={styles.customization} onClick={onCustomizationTextClick}>
          Customization
        </a>
      </div>
      <InfoLinks />
    </header>
  );
};

GroupComponent2.propTypes = {
  className: PropTypes.string,
};

export default GroupComponent2;
