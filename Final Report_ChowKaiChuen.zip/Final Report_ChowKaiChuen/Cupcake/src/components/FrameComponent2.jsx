import { useMemo } from "react";
import PropTypes from "prop-types";
import styles from "./FrameComponent2.module.css";

const FrameComponent2 = ({
  className = "",
  propAlignSelf,
  propWidth,
  customBirthday1,
  happyBirthdayCupcake,
}) => {
  const frameDivStyle = useMemo(() => {
    return {
      alignSelf: propAlignSelf,
      width: propWidth,
    };
  }, [propAlignSelf, propWidth]);

  return (
    <div className={[styles.frameParent, className].join(" ")}>
      <div className={styles.frameWrapper} style={frameDivStyle}>
        <div className={styles.custombirthday1Parent}>
          <img
            className={styles.custombirthday1Icon}
            loading="lazy"
            alt=""
            src={customBirthday1}
          />
          <div className={styles.happyBirthdayCupcake}>
            {happyBirthdayCupcake}
          </div>
        </div>
      </div>
      <div className={styles.frameGroup}>
        <div className={styles.rectangleParent}>
          <div className={styles.frameChild} />
          <div className={styles.rectangleGroup}>
            <div className={styles.frameItem} />
            <div className={styles.div}>-</div>
          </div>
          <div className={styles.wrapper}>
            <div className={styles.div1}>1</div>
          </div>
          <div className={styles.rectangleContainer}>
            <div className={styles.frameItem} />
            <div className={styles.div2}>+</div>
          </div>
        </div>
        <div className={styles.groupDiv}>
          <div className={styles.rectangleDiv} />
          <div className={styles.addToCart}>add to cart</div>
        </div>
      </div>
    </div>
  );
};

FrameComponent2.propTypes = {
  className: PropTypes.string,
  customBirthday1: PropTypes.string,
  happyBirthdayCupcake: PropTypes.string,

  /** Style props */
  propAlignSelf: PropTypes.any,
  propWidth: PropTypes.any,
};

export default FrameComponent2;
