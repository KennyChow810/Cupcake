import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import GroupComponent from "./GroupComponent";
import FrameComponent2 from "./FrameComponent2";
import PropTypes from "prop-types";
import styles from "./Main1.module.css";

const Main1 = ({ className = "" }) => {
  const navigate = useNavigate();

  const onCUPCAKESTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available");
  }, [navigate]);

  const onHolidaysTextClick = useCallback(() => {
    navigate("/cupcakes-holidays-mother-day");
  }, [navigate]);

  const onEventTextClick = useCallback(() => {
    navigate("/cupcakes-event");
  }, [navigate]);

  return (
    <section className={[styles.main, className].join(" ")}>
      <GroupComponent onCUPCAKESTextClick={onCUPCAKESTextClick} />
      <div className={styles.available}>
        <div className={styles.availableItems}>
          <div className={styles.availableTypes}>
            <div className={styles.availableTitle}>
              <h1 className={styles.cupcakes}>CUPCAKES</h1>
            </div>
            <div className={styles.availableOptions}>
              <div className={styles.availableDates}>
                <h1
                  className={styles.alwaysAvailable}
                  onClick={onCUPCAKESTextClick}
                >
                  always available
                </h1>
                <h1 className={styles.holidays} onClick={onHolidaysTextClick}>
                  holidays
                </h1>
              </div>
              <div className={styles.event}>
                <h1 className={styles.event1} onClick={onEventTextClick}>
                  event
                </h1>
              </div>
              <h1 className={styles.others}>others</h1>
            </div>
          </div>
          <div className={styles.price}>
            <h2 className={styles.each}>{`$4 each `}</h2>
          </div>
        </div>
      </div>
      <div className={styles.custom}>
        <div className={styles.customExamples}>
          <div className={styles.kidsCupcake}>
            <div className={styles.kidsImage}>
              <div className={styles.frameParent}>
                <div className={styles.custom21Wrapper}>
                  <img
                    className={styles.custom21Icon}
                    loading="lazy"
                    alt=""
                    src="/custom2-1@2x.png"
                  />
                </div>
                <div className={styles.justForKidsContainer}>
                  <p className={styles.justForKids}>Just for Kids cupcake</p>
                </div>
              </div>
            </div>
            <div className={styles.frameGroup}>
              <div className={styles.rectangleParent}>
                <div className={styles.frameChild} />
                <div className={styles.addSeparator}>
                  <div className={styles.addSeparatorChild} />
                  <div className={styles.div}>-</div>
                </div>
                <div className={styles.wrapper}>
                  <div className={styles.div1}>1</div>
                </div>
                <div className={styles.addSeparator1}>
                  <div className={styles.addSeparatorChild} />
                  <div className={styles.div2}>+</div>
                </div>
              </div>
              <div className={styles.rectangleGroup}>
                <div className={styles.frameItem} />
                <div className={styles.addToCart}>add to cart</div>
              </div>
            </div>
          </div>
          <FrameComponent2
            customBirthday1="/custombirthday-1@2x.png"
            happyBirthdayCupcake="Happy Birthday cupcake"
          />
          <FrameComponent2
            propAlignSelf="unset"
            propWidth="150.9px"
            customBirthday1="/face-1@2x.png"
            happyBirthdayCupcake="Custom Image Cupcake"
          />
        </div>
      </div>
    </section>
  );
};

Main1.propTypes = {
  className: PropTypes.string,
};

export default Main1;
