import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";
import styles from "./FrameComponent6.module.css";

const FrameComponent6 = ({ className = "" }) => {
  const navigate = useNavigate();

  const onAlwaysAvailableTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available");
  }, [navigate]);

  const onHolidaysTextClick = useCallback(() => {
    navigate("/cupcakes-holidays-mother-day");
  }, [navigate]);

  const onEventTextClick = useCallback(() => {
    navigate("/cupcakes-event");
  }, [navigate]);

  const onOthersTextClick = useCallback(() => {
    navigate("/cupcakes-others");
  }, [navigate]);

  const onValentinesDayTextClick = useCallback(() => {
    navigate("/cupcakes-holidays-valentines-day");
  }, [navigate]);

  const onOhCanadaCanadaClick = useCallback(() => {
    navigate("/cupcakes-holidays-oh-canada");
  }, [navigate]);

  const onStPattysDayClick = useCallback(() => {
    navigate("/cupcakes-holidays-st-patty");
  }, [navigate]);

  return (
    <div className={[styles.frameParent, className].join(" ")}>
      <div className={styles.cupcakesWrapper}>
        <h1 className={styles.cupcakes}>CUPCAKES</h1>
      </div>
      <div className={styles.categoriesOptionsWrapper}>
        <div className={styles.categoriesOptions}>
          <div className={styles.categoryTypes}>
            <div className={styles.availabilityOptions}>
              <h1
                className={styles.alwaysAvailable}
                onClick={onAlwaysAvailableTextClick}
              >
                always available
              </h1>
              <h1 className={styles.holidays} onClick={onHolidaysTextClick}>
                holidays
              </h1>
            </div>
            <div className={styles.eventAvailability}>
              <h1 className={styles.event} onClick={onEventTextClick}>
                event
              </h1>
            </div>
            <h1 className={styles.others} onClick={onOthersTextClick}>
              others
            </h1>
          </div>
          <div className={styles.quantityOptions}>
            <h2 className={styles.each24}>
              $3.75 each | $24 half dozen | $48 dozen
            </h2>
          </div>
        </div>
      </div>
      <div className={styles.categoriesParent}>
        <b className={styles.categories}>CATEGORIES</b>
        <div className={styles.categoryList}>
          <div className={styles.mothersDay} onClick={onHolidaysTextClick}>
            mother’s day
          </div>
          <div className={styles.seasonalCategories}>
            <div className={styles.valentinesEasterWrapper}>
              <div className={styles.valentinesEaster}>
                <div className={styles.holidayNames}>
                  <div
                    className={styles.mothersDay}
                    onClick={onValentinesDayTextClick}
                  >
                    Valentine's Day
                  </div>
                </div>
                <div className={styles.holidayNames}>
                  <div className={styles.easter}>EASTER</div>
                </div>
                <div className={styles.holidayNames1}>
                  <div
                    className={styles.mothersDay}
                    onClick={onOhCanadaCanadaClick}
                  >
                    Oh Canada! Canada Day
                  </div>
                </div>
                <div className={styles.mothersDay} onClick={onStPattysDayClick}>
                  St Patty's Day cupcake
                </div>
              </div>
            </div>
            <div className={styles.easterImageParent}>
              <div className={styles.easterImage}>
                <img
                  className={styles.easter1Icon}
                  loading="lazy"
                  alt=""
                  src="/easter-1@2x.png"
                />
              </div>
              <div className={styles.easterProduct}>
                <div className={styles.easter1}>Easter</div>
                <div className={styles.frameGroup}>
                  <div className={styles.rectangleParent}>
                    <div className={styles.frameChild} />
                    <div className={styles.addButtonInfo}>
                      <div className={styles.addButtonInfoChild} />
                      <div className={styles.separator}>-</div>
                    </div>
                    <div className={styles.wrapper}>
                      <div className={styles.div}>1</div>
                    </div>
                    <div className={styles.addButtonInfo1}>
                      <div className={styles.addButtonInfoChild} />
                      <div className={styles.div1}>+</div>
                    </div>
                  </div>
                  <div className={styles.rectangleGroup}>
                    <div className={styles.frameItem} />
                    <div className={styles.addToCart}>add to cart</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

FrameComponent6.propTypes = {
  className: PropTypes.string,
};

export default FrameComponent6;
