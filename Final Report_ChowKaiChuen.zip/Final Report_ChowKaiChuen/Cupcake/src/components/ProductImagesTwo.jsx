import { useMemo } from "react";
import PropTypes from "prop-types";
import styles from "./ProductImagesTwo.module.css";

const ProductImagesTwo = ({
  className = "",
  propPadding,
  propGap,
  propWidth,
  propAlignSelf,
  image21,
  propMixBlendMode,
  chocolateCaramel,
}) => {
  const productImagesTwoStyle = useMemo(() => {
    return {
      padding: propPadding,
      gap: propGap,
    };
  }, [propPadding, propGap]);

  const productImageValuesTwoStyle = useMemo(() => {
    return {
      width: propWidth,
      alignSelf: propAlignSelf,
    };
  }, [propWidth, propAlignSelf]);

  const image21IconStyle = useMemo(() => {
    return {
      mixBlendMode: propMixBlendMode,
    };
  }, [propMixBlendMode]);

  return (
    <div
      className={[styles.productImagesTwo, className].join(" ")}
      style={productImagesTwoStyle}
    >
      <div
        className={styles.productImageValuesTwo}
        style={productImageValuesTwoStyle}
      >
        <img
          className={styles.image21Icon}
          loading="lazy"
          alt=""
          src={image21}
          style={image21IconStyle}
        />
      </div>
      <div className={styles.productNamesTwo}>
        <div className={styles.productNameValuesTwo}>
          <div className={styles.chocolateCaramel}>{chocolateCaramel}</div>
        </div>
        <div className={styles.productDetailsTwo}>
          <div className={styles.rectangleParent}>
            <div className={styles.frameChild} />
            <div className={styles.caramelPrices}>
              <div className={styles.caramelPricesChild} />
              <div className={styles.sundaeQuantity}>-</div>
            </div>
            <div className={styles.sundaePrices}>
              <div className={styles.mochaQuantity}>1</div>
            </div>
            <div className={styles.mochaPrices}>
              <div className={styles.caramelPricesChild} />
              <div className={styles.caramelCartButton}>+</div>
            </div>
          </div>
          <div className={styles.rectangleGroup}>
            <div className={styles.frameItem} />
            <div className={styles.addToCart}>add to cart</div>
          </div>
        </div>
      </div>
    </div>
  );
};

ProductImagesTwo.propTypes = {
  className: PropTypes.string,
  image21: PropTypes.string,
  chocolateCaramel: PropTypes.string,

  /** Style props */
  propPadding: PropTypes.any,
  propGap: PropTypes.any,
  propWidth: PropTypes.any,
  propAlignSelf: PropTypes.any,
  propMixBlendMode: PropTypes.any,
};

export default ProductImagesTwo;
