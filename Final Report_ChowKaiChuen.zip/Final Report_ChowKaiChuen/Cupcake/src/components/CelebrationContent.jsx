import PropTypes from "prop-types";
import styles from "./CelebrationContent.module.css";

const CelebrationContent = ({ className = "" }) => {
  return (
    <div className={[styles.celebrationContent, className].join(" ")}>
      <div className={styles.celebrationDescription}>
        <h2 className={styles.aCelebrationOfContainer}>
          <p className={styles.aCelebrationOf}>
            A celebration of life, love, and all of life's memorable
            events Toronto Cupcake would love to help make your special occasion
            one to remember.
          </p>
        </h2>
      </div>
      <div className={styles.weddingTypesParent}>
        <div className={styles.weddingTypes}>
          <div className={styles.weddingType}>
            <div className={styles.weddingTypeContainer}>
              <div className={styles.weddingImage}>
                <img
                  className={styles.wedding11Icon}
                  loading="lazy"
                  alt=""
                  src="/wedding1-1@2x.png"
                />
              </div>
              <img
                className={styles.wedding31Icon}
                loading="lazy"
                alt=""
                src="/wedding3-1@2x.png"
              />
              <img
                className={styles.wedding21Icon}
                loading="lazy"
                alt=""
                src="/wedding2-1@2x.png"
              />
            </div>
          </div>
          <div className={styles.welcomeMessage}>
            <div className={styles.welcomeThankYouContainer}>
              <p className={styles.aCelebrationOf}>
                <span className={styles.weddingAndEngagement1}>
                  Wedding and Engagement
                </span>
                <span> </span>
              </p>
              <p className={styles.aCelebrationOf}>
                we have over 1500 different combinations with our standard
                offerings but if you want something special we would love to
                make it happen. We have many different sized and shaped cupcake
                stands available for your use or we can design and make one just
                for you.
              </p>
            </div>
            <div className={styles.welcomeMessageInner}>
              <div className={styles.frameChild} />
            </div>
          </div>
        </div>
        <div className={styles.happyBirthdayImage}>
          <img
            className={styles.happyBirthday11}
            loading="lazy"
            alt=""
            src="/happy-birthday1-1@2x.png"
          />
        </div>
        <div className={styles.welcomeThankYouContainer1}>
          <p className={styles.aCelebrationOf}>
            <span className={styles.weddingAndEngagement1}>
              Birthdays/Anniversaries
            </span>
            <span> </span>
          </p>
          <p className={styles.aCelebrationOf}>
            Themed birthdays or anniversaries are all the rage. From Cookie
            Monster to The Bachelorette we have done them all.
          </p>
        </div>
        <div className={styles.lineWrapper}>
          <div className={styles.frameChild} />
        </div>
      </div>
    </div>
  );
};

CelebrationContent.propTypes = {
  className: PropTypes.string,
};

export default CelebrationContent;
