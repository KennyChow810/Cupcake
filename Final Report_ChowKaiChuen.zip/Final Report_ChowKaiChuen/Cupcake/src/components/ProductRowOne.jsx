import { useMemo } from "react";
import PropTypes from "prop-types";
import styles from "./ProductRowOne.module.css";

const ProductRowOne = ({
  className = "",
  propPadding,
  propGap,
  propAlignSelf,
  propWidth,
  image19,
  propWidth1,
  propFlex,
  propOverflow,
  vanillaChocolate,
  propAlignSelf1,
  propWidth2,
  propWidth3,
  propAlignSelf2,
}) => {
  const productRowOneStyle = useMemo(() => {
    return {
      padding: propPadding,
      gap: propGap,
    };
  }, [propPadding, propGap]);

  const productImagesOneStyle = useMemo(() => {
    return {
      alignSelf: propAlignSelf,
      width: propWidth,
    };
  }, [propAlignSelf, propWidth]);

  const image19IconStyle = useMemo(() => {
    return {
      width: propWidth1,
      flex: propFlex,
      overflow: propOverflow,
    };
  }, [propWidth1, propFlex, propOverflow]);

  const vanillaChocolateStyle = useMemo(() => {
    return {
      alignSelf: propAlignSelf1,
      width: propWidth2,
    };
  }, [propAlignSelf1, propWidth2]);

  const productDetailsOneStyle = useMemo(() => {
    return {
      width: propWidth3,
      alignSelf: propAlignSelf2,
    };
  }, [propWidth3, propAlignSelf2]);

  return (
    <div
      className={[styles.productRowOne, className].join(" ")}
      style={productRowOneStyle}
    >
      <div className={styles.productImagesOne} style={productImagesOneStyle}>
        <img
          className={styles.image19Icon}
          loading="lazy"
          alt=""
          src={image19}
          style={image19IconStyle}
        />
      </div>
      <div className={styles.productNamesOne}>
        <div className={styles.vanillaChocolate} style={vanillaChocolateStyle}>
          {vanillaChocolate}
        </div>
        <div
          className={styles.productDetailsOne}
          style={productDetailsOneStyle}
        >
          <div className={styles.productActionsOne}>
            <div className={styles.rectangleParent}>
              <div className={styles.frameChild} />
              <div className={styles.quantityOne}>
                <div className={styles.quantityOneChild} />
                <div className={styles.quantityValuesOne}>-</div>
              </div>
              <div className={styles.priceOne}>
                <div className={styles.priceValuesOne}>1</div>
              </div>
              <div className={styles.availabilityOne}>
                <div className={styles.quantityOneChild} />
                <div className={styles.availabilityValuesOne}>+</div>
              </div>
            </div>
            <div className={styles.rectangleGroup}>
              <div className={styles.frameItem} />
              <div className={styles.addToCart}>add to cart</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

ProductRowOne.propTypes = {
  className: PropTypes.string,
  image19: PropTypes.string,
  vanillaChocolate: PropTypes.string,

  /** Style props */
  propPadding: PropTypes.any,
  propGap: PropTypes.any,
  propAlignSelf: PropTypes.any,
  propWidth: PropTypes.any,
  propWidth1: PropTypes.any,
  propFlex: PropTypes.any,
  propOverflow: PropTypes.any,
  propAlignSelf1: PropTypes.any,
  propWidth2: PropTypes.any,
  propWidth3: PropTypes.any,
  propAlignSelf2: PropTypes.any,
};

export default ProductRowOne;
