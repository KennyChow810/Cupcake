import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";
import styles from "./GroupComponent.module.css";

const GroupComponent = ({ className = "", onCUPCAKESTextClick }) => {
  const navigate = useNavigate();

  const onHOMETextClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  const onCorporateEventTextClick = useCallback(() => {
    navigate("/corporate-event");
  }, [navigate]);

  const onCustomizationTextClick = useCallback(() => {
    navigate("/customization");
  }, [navigate]);

  const onABOUTUSTextClick = useCallback(() => {
    navigate("/about-us");
  }, [navigate]);

  const onCONTACTTextClick = useCallback(() => {
    navigate("/contact");
  }, [navigate]);

  const onFAQsTextClick = useCallback(() => {
    navigate("/faqs");
  }, [navigate]);

  const onCartIconClick = useCallback(() => {
    navigate("/cart");
  }, [navigate]);

  return (
    <header className={[styles.rectangleParent, className].join(" ")}>
      <div className={styles.frameChild} />
      <div className={styles.torontoLogoParent}>
        <img
          className={styles.torontoLogoIcon}
          loading="lazy"
          alt=""
          src="/toronto-logo@2x.png"
        />
        <div className={styles.homeButton}>
          <a className={styles.home} onClick={onHOMETextClick}>
            HOME
          </a>
        </div>
      </div>
      <div className={styles.cupcakesTitle}>
        <div className={styles.cupcakesParent}>
          <a className={styles.cupcakes} onClick={onCUPCAKESTextClick}>
            CUPCAKES
          </a>
          <div className={styles.lineWrapper}>
            <div className={styles.frameItem} />
          </div>
        </div>
      </div>
      <div className={styles.homeButton}>
        <a
          className={styles.corporateEvent}
          onClick={onCorporateEventTextClick}
        >
          corporate event
        </a>
      </div>
      <div className={styles.homeButton}>
        <a className={styles.corporateEvent} onClick={onCustomizationTextClick}>
          Customization
        </a>
      </div>
      <div className={styles.navigationMenu}>
        <div className={styles.menuButtonContainerParent}>
          <nav className={styles.menuButtonContainer}>
            <nav className={styles.menuButtons}>
              <a className={styles.aboutUs} onClick={onABOUTUSTextClick}>
                ABOUT US
              </a>
              <a className={styles.contact} onClick={onCONTACTTextClick}>
                CONTACT
              </a>
              <a className={styles.faqs} onClick={onFAQsTextClick}>
                FAQs
              </a>
            </nav>
          </nav>
          <img
            className={styles.cartIcon}
            loading="lazy"
            alt=""
            src="/cart@2x.png"
            onClick={onCartIconClick}
          />
        </div>
      </div>
    </header>
  );
};

GroupComponent.propTypes = {
  className: PropTypes.string,

  /** Action props */
  onCUPCAKESTextClick: PropTypes.func,
};

export default GroupComponent;
