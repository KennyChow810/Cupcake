import { useCallback } from "react";
import FrameComponent from "./FrameComponent";
import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";
import styles from "./GroupComponent5.module.css";

const GroupComponent5 = ({ className = "" }) => {
  const navigate = useNavigate();

  const onCUPCAKESTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available");
  }, [navigate]);

  const onCorporateEventTextClick = useCallback(() => {
    navigate("/corporate-event");
  }, [navigate]);

  const onCustomizationTextClick = useCallback(() => {
    navigate("/customization");
  }, [navigate]);

  const onABOUTUSTextClick = useCallback(() => {
    navigate("/about-us");
  }, [navigate]);

  const onCONTACTTextClick = useCallback(() => {
    navigate("/contact");
  }, [navigate]);

  const onCartIconClick = useCallback(() => {
    navigate("/cart");
  }, [navigate]);

  return (
    <header className={[styles.rectangleParent, className].join(" ")}>
      <div className={styles.frameChild} />
      <FrameComponent hOMEPadding="0px 10px 0px 0px" />
      <div className={styles.infoCategories}>
        <a className={styles.cupcakes} onClick={onCUPCAKESTextClick}>
          CUPCAKES
        </a>
      </div>
      <div className={styles.infoCategories1}>
        <a
          className={styles.corporateEvent}
          onClick={onCorporateEventTextClick}
        >
          corporate event
        </a>
      </div>
      <div className={styles.infoCategories2}>
        <a className={styles.corporateEvent} onClick={onCustomizationTextClick}>
          Customization
        </a>
      </div>
      <div className={styles.aboutContact}>
        <div className={styles.aboutUsParent}>
          <a className={styles.aboutUs} onClick={onABOUTUSTextClick}>
            ABOUT US
          </a>
          <a className={styles.contact} onClick={onCONTACTTextClick}>
            CONTACT
          </a>
        </div>
      </div>
      <div className={styles.faqsIntro}>
        <div className={styles.faqsHeader}>
          <div className={styles.faqsTitle}>
            <div className={styles.faqsHeading}>
              <a className={styles.faqs}>FAQs</a>
            </div>
            <div className={styles.titleSeparator} />
          </div>
          <div className={styles.cartIcon}>
            <img
              className={styles.cartIcon1}
              loading="lazy"
              alt=""
              src="/cart@2x.png"
              onClick={onCartIconClick}
            />
          </div>
        </div>
      </div>
    </header>
  );
};

GroupComponent5.propTypes = {
  className: PropTypes.string,
};

export default GroupComponent5;
