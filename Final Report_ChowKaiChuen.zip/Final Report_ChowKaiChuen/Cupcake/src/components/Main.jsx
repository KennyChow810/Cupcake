import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import GroupComponent from "./GroupComponent";
import ProductVariations from "./ProductVariations";
import PropTypes from "prop-types";
import styles from "./Main.module.css";

const Main = ({ className = "" }) => {
  const navigate = useNavigate();

  const onCUPCAKESTextClick = useCallback(() => {
    navigate("/-cupcakes-always-available");
  }, [navigate]);

  const onHolidaysTextClick = useCallback(() => {
    navigate("/cupcakes-holidays-mother-day");
  }, [navigate]);

  const onOthersTextClick = useCallback(() => {
    navigate("/cupcakes-others");
  }, [navigate]);

  return (
    <section className={[styles.main, className].join(" ")}>
      <GroupComponent onCUPCAKESTextClick={onCUPCAKESTextClick} />
      <div className={styles.content}>
        <div className={styles.description}>
          <div className={styles.descriptionTitle}>
            <h1 className={styles.cupcakes}>CUPCAKES</h1>
          </div>
          <div className={styles.availability}>
            <div className={styles.occasionTypes}>
              <h1
                className={styles.alwaysAvailable}
                onClick={onCUPCAKESTextClick}
              >
                always available
              </h1>
              <h1 className={styles.holidays} onClick={onHolidaysTextClick}>
                holidays
              </h1>
            </div>
            <div className={styles.events}>
              <h1 className={styles.event}>event</h1>
            </div>
            <h1 className={styles.others} onClick={onOthersTextClick}>
              others
            </h1>
          </div>
          <div className={styles.products}>
            <div className={styles.productGrid}>
              <div className={styles.productCard}>
                <div className={styles.each}>{`$3.75 each `}</div>
              </div>
              <div className={styles.productDetails}>
                <div className={styles.productVariations}>
                  <div className={styles.variationNames}>
                    <img
                      className={styles.prideday1Icon}
                      loading="lazy"
                      alt=""
                      src="/prideday-1@2x.png"
                    />
                  </div>
                  <div className={styles.frameParent}>
                    <div className={styles.rectangleParent}>
                      <div className={styles.frameChild} />
                      <div className={styles.rectangleGroup}>
                        <div className={styles.frameItem} />
                        <div className={styles.div}>-</div>
                      </div>
                      <div className={styles.wrapper}>
                        <div className={styles.div1}>1</div>
                      </div>
                      <div className={styles.rectangleContainer}>
                        <div className={styles.frameItem} />
                        <div className={styles.div2}>+</div>
                      </div>
                    </div>
                    <div className={styles.groupDiv}>
                      <div className={styles.rectangleDiv} />
                      <div className={styles.addToCart}>add to cart</div>
                    </div>
                  </div>
                </div>
                <ProductVariations jazz1="/jazz-1@2x.png" />
                <ProductVariations
                  propGap="67.6px"
                  jazz1="/tiff-1@2x.png"
                  propHeight="170.4px"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

Main.propTypes = {
  className: PropTypes.string,
};

export default Main;
