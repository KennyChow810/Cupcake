import LastNameContact from "./LastNameContact";
import Footer from "./Footer";
import PropTypes from "prop-types";
import styles from "./FrameComponent4.module.css";

const FrameComponent4 = ({ className = "" }) => {
  return (
    <section className={[styles.formAndFooterParent, className].join(" ")}>
      <div className={styles.formAndFooter}>
        <div className={styles.formAndFooterChild} />
        <div className={styles.formHeading}>
          <h2 className={styles.tellUsYour}>
            Tell us your needs and we will contact you asap
          </h2>
        </div>
        <div className={styles.frameParent}>
          <div className={styles.rectangleParent}>
            <div className={styles.frameChild} />
            <div className={styles.send}>Send</div>
          </div>
          <div className={styles.nameMessage}>
            <div className={styles.firstName}>First Name</div>
            <input type="text" className={styles.nameMessageBackground} />
            <div className={styles.emailInput}>
              <div className={styles.email}>Email</div>
              <input type="text" className={styles.nameMessageBackground} />
            </div>
            <div className={styles.message}>Message</div>
          </div>
          <LastNameContact />
          <input type="text" className={styles.frameItem} />
        </div>
      </div>
      <Footer propMarginTop="unset" rectangle146="/rectangle-146.svg" />
    </section>
  );
};

FrameComponent4.propTypes = {
  className: PropTypes.string,
};

export default FrameComponent4;
