import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";
import styles from "./Header.module.css";

const Header = ({ className = "" }) => {
  const navigate = useNavigate();

  const onCTAContainerClick = useCallback(() => {
    navigate("/-cupcakes-always-available");
  }, [navigate]);

  return (
    <section className={[styles.header, className].join(" ")}>
      <div className={styles.welcomeMessage}>
        <h1 className={styles.welcomeToToronto}>Welcome to TORONTO CUPCAKE</h1>
        <div className={styles.welcomeParagraph}>
          <div className={styles.welcomeThankYouContainer}>
            <p className={styles.welcomeThankYou}>
              Welcome! Thank you for stopping by Toronto Cupcake. Canada's and
              the GTA's favourite stop for that special treat. Order cupcakes
              online 24/7 for your special event. Delivery avaialable most days
              between 8 and 6pm TO time.
            </p>
            <p className={styles.welcomeThankYou}>&nbsp;</p>
            <p className={styles.welcomeThankYou}>
              Celebrating our 13th year of providing Canada's most delicious
              cupcakes for business meetings, birthdays, weddings, or for no
              other reason than because.
            </p>
            <p className={styles.welcomeThankYou}>&nbsp;</p>
            <p className={styles.welcomeThankYou}>
              Our cupcakes are baked daily using the finest ingredients.
            </p>
            <p className={styles.welcomeThankYou}>&nbsp;</p>
            <p className={styles.welcomeThankYou}>
              Cupcake delivery is available throughout Toronto, the GTA, and
              beyond. Cupcakes are delivered in our signature pink box.
            </p>
          </div>
          <div className={styles.callToAction}>
            <div className={styles.cta} onClick={onCTAContainerClick}>
              <div className={styles.buttonBackground} />
              <div className={styles.shopNowWrapper}>
                <div className={styles.shopNow}>SHOP NOW</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

Header.propTypes = {
  className: PropTypes.string,
};

export default Header;
