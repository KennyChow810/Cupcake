import PropTypes from "prop-types";
import styles from "./FrameComponent3.module.css";

const FrameComponent3 = ({ className = "" }) => {
  return (
    <section className={[styles.heroContentParent, className].join(" ")}>
      <div className={styles.heroContent}>
        <div className={styles.aboutTorontoCupcakeParent}>
          <h1 className={styles.aboutTorontoCupcake}>About Toronto Cupcake</h1>
          <div className={styles.welcomeThankYou}>
            We are driven by loving what we do and what we make everyday. We get
            to use the finest ingredients to make what we believe are the
            tastiest treats around. And.. we love the idea that our treats are
            making people happy every time they bite into one. How much fun is
            that!
          </div>
        </div>
        <div className={styles.heroImage}>
          <img
            className={styles.main1Icon}
            loading="lazy"
            alt=""
            src="/main-1@2x.png"
          />
        </div>
      </div>
      <div className={styles.dividerWrapper}>
        <div className={styles.divider} />
      </div>
    </section>
  );
};

FrameComponent3.propTypes = {
  className: PropTypes.string,
};

export default FrameComponent3;
