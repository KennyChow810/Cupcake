import { useMemo, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";
import styles from "./FrameComponent.module.css";

const FrameComponent = ({ className = "", hOMEPadding }) => {
  const frameDiv1Style = useMemo(() => {
    return {
      padding: hOMEPadding,
    };
  }, [hOMEPadding]);

  const navigate = useNavigate();

  const onHOMETextClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  return (
    <div
      className={[styles.torontoLogoParent, className].join(" ")}
      style={frameDiv1Style}
    >
      <img
        className={styles.torontoLogoIcon}
        loading="lazy"
        alt=""
        src="/toronto-logo@2x.png"
      />
      <div className={styles.homeButton}>
        <a className={styles.home} onClick={onHOMETextClick}>
          HOME
        </a>
      </div>
    </div>
  );
};

FrameComponent.propTypes = {
  className: PropTypes.string,

  /** Style props */
  hOMEPadding: PropTypes.any,
};

export default FrameComponent;
