import { useEffect } from "react";
import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import HomePage from "./pages/HomePage";
import Customization from "./pages/Customization";
import Contact from "./pages/Contact";
import CupcakesOthers from "./pages/CupcakesOthers";
import CorporateEvent from "./pages/CorporateEvent";
import CupcakesAlwaysAvailable1 from "./pages/CupcakesAlwaysAvailable1";
import CupcakesAlwaysAvailable2 from "./pages/CupcakesAlwaysAvailable2";
import CupcakesHolidaysMotherD from "./pages/CupcakesHolidaysMotherD";
import CupcakesHolidaysSTPatty from "./pages/CupcakesHolidaysSTPatty";
import CupcakesHolidaysEaster from "./pages/CupcakesHolidaysEaster";
import AboutUs from "./pages/AboutUs";
import CupcakesAlwaysAvailable4 from "./pages/CupcakesAlwaysAvailable4";
import CupcakesEvent from "./pages/CupcakesEvent";
import Cart from "./pages/Cart";
import CupcakesHolidaysOHCanad from "./pages/CupcakesHolidaysOHCanad";
import CupcakesAlwaysAvailable3 from "./pages/CupcakesAlwaysAvailable3";
import FAQs from "./pages/FAQs";
import CupcakesAlwaysAvailable from "./pages/CupcakesAlwaysAvailable";
import CupcakesHolidaysValentin from "./pages/CupcakesHolidaysValentin";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/customization":
        title = "";
        metaDescription = "";
        break;
      case "/contact":
        title = "";
        metaDescription = "";
        break;
      case "/cupcakes-others":
        title = "";
        metaDescription = "";
        break;
      case "/corporate-event":
        title = "";
        metaDescription = "";
        break;
      case "/-cupcakes-always-available-choclate":
        title = "";
        metaDescription = "";
        break;
      case "/-cupcakes-always-available-vanilla":
        title = "";
        metaDescription = "";
        break;
      case "/cupcakes-holidays-mother-day":
        title = "";
        metaDescription = "";
        break;
      case "/cupcakes-holidays-st-patty":
        title = "";
        metaDescription = "";
        break;
      case "/cupcakes-holidays-easter":
        title = "";
        metaDescription = "";
        break;
      case "/about-us":
        title = "";
        metaDescription = "";
        break;
      case "/-cupcakes-always-available-one-dozen-assorted-box":
        title = "";
        metaDescription = "";
        break;
      case "/cupcakes-event":
        title = "";
        metaDescription = "";
        break;
      case "/cart":
        title = "";
        metaDescription = "";
        break;
      case "/cupcakes-holidays-oh-canada":
        title = "";
        metaDescription = "";
        break;
      case "/-cupcakes-always-available-red-velvet":
        title = "";
        metaDescription = "";
        break;
      case "/faqs":
        title = "";
        metaDescription = "";
        break;
      case "/-cupcakes-always-available":
        title = "";
        metaDescription = "";
        break;
      case "/cupcakes-holidays-valentines-day":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/customization" element={<Customization />} />
      <Route path="/contact" element={<Contact />} />
      <Route path="/cupcakes-others" element={<CupcakesOthers />} />
      <Route path="/corporate-event" element={<CorporateEvent />} />
      <Route
        path="/-cupcakes-always-available-choclate"
        element={<CupcakesAlwaysAvailable1 />}
      />
      <Route
        path="/-cupcakes-always-available-vanilla"
        element={<CupcakesAlwaysAvailable2 />}
      />
      <Route
        path="/cupcakes-holidays-mother-day"
        element={<CupcakesHolidaysMotherD />}
      />
      <Route
        path="/cupcakes-holidays-st-patty"
        element={<CupcakesHolidaysSTPatty />}
      />
      <Route
        path="/cupcakes-holidays-easter"
        element={<CupcakesHolidaysEaster />}
      />
      <Route path="/about-us" element={<AboutUs />} />
      <Route
        path="/-cupcakes-always-available-one-dozen-assorted-box"
        element={<CupcakesAlwaysAvailable4 />}
      />
      <Route path="/cupcakes-event" element={<CupcakesEvent />} />
      <Route path="/cart" element={<Cart />} />
      <Route
        path="/cupcakes-holidays-oh-canada"
        element={<CupcakesHolidaysOHCanad />}
      />
      <Route
        path="/-cupcakes-always-available-red-velvet"
        element={<CupcakesAlwaysAvailable3 />}
      />
      <Route path="/faqs" element={<FAQs />} />
      <Route
        path="/-cupcakes-always-available"
        element={<CupcakesAlwaysAvailable />}
      />
      <Route
        path="/cupcakes-holidays-valentines-day"
        element={<CupcakesHolidaysValentin />}
      />
    </Routes>
  );
}
export default App;
